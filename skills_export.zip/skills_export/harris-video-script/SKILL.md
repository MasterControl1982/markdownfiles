---
name: harris-video-script
description: Research any topic and produce a fully-cited, 20-minute video script written in the Johnny Harris explainer-journalism style (personal investigation, maps-and-motion-graphics visual language, hook → context → investigation → reveal → "so what" arc). Use this skill whenever the user gives a topic and asks for a video script, explainer script, YouTube script, documentary-style script, or "Johnny Harris style" content — even if they just say "do the harris script for X", "make a video about X", or "run the script skill on X". Also trigger when the user asks for a researched narrative with citations intended for video narration.
---

# Harris Video Script Generator

Turn a single topic into three deliverables:
1. **Research brief** — the factual foundation, every claim sourced
2. **Narrative outline** — the story arc mapped to the Harris structure
3. **Full 20-minute script** — two-column format (visuals + voiceover), with on-screen citation callouts

Read `references/style-guide.md` before writing any script prose. It defines the voice, pacing, structure, and visual language. Do not skip it — the style is the product.

## Step 0 — Clarify scope (only if needed)

If the topic is broad ("China", "the economy"), ask ONE question to find the angle — Harris videos are built on a specific question or anomaly, not a survey. If the topic already implies an angle ("why the Kazakhstan/Uzbekistan border zigzags"), proceed without asking.

## Step 1 — Research (web search, 5–10 searches)

A 20-minute script needs real depth. Research in layers:

1. **Orientation search** — what is the current state of this topic? What do most people get wrong about it?
2. **The anomaly** — find the surprising fact, contradiction, or hidden detail that becomes the hook.
3. **Historical roots** — the "to understand this, we go back to..." layer. Find the origin event, decision, or person.
4. **Primary-ish sources** — government reports, academic papers, declassified docs, official statistics, direct interviews in reputable outlets. Prefer these over aggregators.
5. **The human stakes** — a concrete person, place, or number that makes it real.
6. **Counter-narrative** — where do credible sources disagree? Harris always marks the line between documented fact and interpretation.

Use `web_fetch` to read full articles when snippets aren't enough — a 20-minute script can't run on headlines.

**Citation discipline:**
- Every factual claim in the final script must trace to a source collected in this step.
- Log each source as: `[S#] Title — Publisher — URL — what it supports`
- Never invent sources. If a claim can't be sourced, cut it or explicitly flag it as unverified in the script ("this part is disputed").
- Paraphrase everything; no quotes over 15 words, max one short quote per source.

## Step 2 — Narrative outline

Map findings onto the Harris Arc (full detail in `references/style-guide.md`):

```
COLD OPEN (0:00–1:00)   — anomaly/question + personal obsession + stakes + tease
TITLE BEAT              — "This is a story about ____."
CONTEXT (1:00–5:00)     — history compressed, maps/animation
INVESTIGATION (5:00–16:00) — 4–6 discovery beats, each ending in a new question;
                             include a mid-video twist ("here's where it gets weird")
REVEAL (16:00–18:00)    — the core answer
SO WHAT (18:00–20:00)   — zoom out to theme, moral tension, direct address
```

Each beat in the outline gets: the question it answers, the key facts (with [S#] tags), and the emotional register (curiosity / tension / outrage / wonder).

Show the outline to the user briefly before drafting the full script ONLY if the research surfaced multiple viable angles. Otherwise proceed straight to the script.

## Step 3 — Write the script

**Length math:** 20 minutes at ~150 words/minute of narration = **2,800–3,200 words of voiceover**. Count it. Under 2,600 is too short; over 3,400 will run long.

**Format:** create a markdown file in `/mnt/user-data/outputs/` named `<topic-slug>-script.md` using this template:

```markdown
# [Video Title — punchy, question-based]
**Runtime target:** 20:00 | **VO word count:** [actual count]

## COLD OPEN [0:00–1:00]

[VISUAL: globe zoom to X, border lines drawing on]
**VO:** Script prose here... [S3]

[VISUAL: Johnny at desk, holding printed map]
**ON CAMERA:** Direct-address prose here...

---
## [next section...]
---
## SOURCES
[S1] Title — Publisher — URL
[S2] ...
```

Rules while drafting:
- Follow every voice/pacing rule in `references/style-guide.md` — first person, short punchy sentences, beat drops, rhetorical-question transitions, "to understand this we have to go back," self-aware uncertainty.
- Visual directions on their own lines, concrete and producible (map zooms, kinetic type, archival, screen recordings, desk shots). Something visual changes every 30–60 seconds.
- Inline `[S#]` tags after each sourced claim — these become on-screen citations in the edit.
- Mark fact vs. interpretation explicitly at least once ("Now, this part is documented. What happens next is where historians disagree.").
- End on meaning and tension, not a tidy bow.

## Step 4 — Deliver

Present the script file via `present_files`. In chat, give a 3–4 sentence summary: the hook, the twist, the reveal, and the source count. Offer one concrete next step (e.g., tighten a section, generate B-roll shot list, or shorten to a 10-minute cut).

## Quality bar (self-check before delivering)

- [ ] VO word count is 2,800–3,200 and stated in the file
- [ ] Every factual claim has an [S#] tag; every [S#] resolves to a real URL in SOURCES
- [ ] Cold open poses the question within the first 3 sentences
- [ ] At least one mid-video reframe/twist
- [ ] At least one fact-vs-interpretation marker
- [ ] Visual direction changes at least every 60 seconds of runtime
- [ ] Ending raises a tension, doesn't just summarize
