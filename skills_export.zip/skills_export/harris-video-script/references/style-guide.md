# Johnny Harris Style Guide
### A framework for scripting videos in his journalistic style

---

## 1. Core Identity

Johnny Harris makes **explainer journalism** — geopolitics, maps, history, borders, power, and "why the world is the way it is." His videos feel like a personal investigation, not a news report. The defining trait: **he is a character in the story**. The audience follows *his* curiosity, *his* confusion, *his* discovery.

**One-line summary of the style:**
> "I had a question. I went down a rabbit hole. Let me show you what I found — and why it matters to you."

---

## 2. Narrative Structure (The Harris Arc)

### Act 1 — The Hook (0:00–0:45)
- Open with a **provocative question, anomaly, or contradiction**: "Why does this border look like this?" / "There's a country that technically doesn't exist."
- Often starts mid-thought or with a surprising visual/map.
- Personal framing: "I've been obsessed with this for years."
- **Stakes established fast**: why should a normal person care?
- Frequently teases the payoff: "And the answer changed how I see the entire world."

### Act 2 — The Setup / Context
- Zoom WAY out. Historical context, often going back decades or centuries.
- Uses the phrase pattern: "But to understand X, we have to go back to..."
- Simplifies without dumbing down — complex systems explained through one concrete example or character.

### Act 3 — The Investigation
- Structured as a journey of discovery: "So I started digging." / "I called an expert." / "I found this document."
- **Show the work**: archival footage, declassified documents, interviews, screen recordings of him researching.
- Builds in layers — each answer reveals a new question.
- Mid-video twist or reframe: "But here's where it gets weird."

### Act 4 — The Reveal + The "So What"
- The core answer, delivered with energy.
- Then the pivot to meaning: what this says about power, money, human nature, or the future.
- Often ends on ambiguity or a moral tension rather than a tidy bow: "I don't know the answer. But I know we should be asking the question."

---

## 3. Voice & Tone

| Trait | How it sounds |
|---|---|
| **First person, confessional** | "I didn't know this. And honestly, it kind of blew my mind." |
| **Conversational, not formal** | Contractions, casual asides, "okay so," "here's the thing," "stick with me." |
| **Earnest curiosity** | Genuine wonder, never cynical detachment. He's excited to learn. |
| **Controlled outrage** | When covering injustice, he lets emotion in — but grounds it in evidence. |
| **Self-aware** | Acknowledges his own bias, limits, and privilege: "I'm an American looking at this from the outside." |
| **Direct address** | Talks TO the viewer: "You've probably seen this map before. But have you ever noticed..." |

### Signature verbal patterns
- "Let me show you what I mean."
- "But to understand that, we need to go back."
- "And that's when I realized..."
- "Here's where it gets interesting/weird/dark."
- "This is a story about [big abstract theme]." (power, borders, greed, memory)
- Rhetorical questions as transitions: "So why did they do this?"
- Repetition for emphasis: "Maps. Maps are everywhere. Maps shape how we think."

---

## 4. Pacing & Rhythm

- **Short sentences. Punchy.** Then a longer sentence that unspools the idea before snapping back. Short again.
- Frequent **beat drops**: a dramatic pause (in script: line break / "beat") before a reveal.
- Sentence fragments used deliberately: "A secret deal. Signed in the dark. And no one talked about it for fifty years."
- Information delivered in **waves**: tension → release → new tension.
- Roughly every 30–60 seconds, something changes: new visual, new question, new location, tone shift.

---

## 5. Visual Language (script for the edit)

Even in a script, write **visual directions** — his videos are map-and-motion-graphics driven:

- **Maps as protagonist**: zooming globes, animated borders shifting over time, highlighted regions.
- **Kinetic typography**: key phrases appear on screen as he says them.
- **Archival mix**: old footage, newspaper clippings, photos with subtle parallax/animation.
- **The desk/study shot**: him talking directly to camera in a warm, lamp-lit room — intimacy anchor between graphic sequences.
- **Paper & tactile props**: printed maps, documents he physically holds and points at.
- **Screen recordings**: Google Earth flights, him scrolling sources — "showing the homework."
- Color grade: warm, filmic, slightly desaturated.
- Music: pulsing, cinematic, builds under reveals, cuts to silence for emphasis.

**Script formatting tip:** two-column or bracketed format —
```
[GLOBE ZOOM: spinning to Central Asia, border lines drawing on]
VO: This line right here? It was drawn by one man. In an afternoon.
[BEAT — cut to Johnny at desk, holding printed map]
JOHNNY (to camera): And that afternoon changed millions of lives.
```

---

## 6. Research & Credibility Habits

- Cites sources on screen (small text citations under graphics).
- Interviews 1–3 experts, cut into short authoritative clips.
- Distinguishes fact from interpretation: "Now, this part is documented. What happens next is where historians disagree."
- Transparent about uncertainty — builds trust through humility.
- Often includes a "how I know this" beat: FOIA docs, academic papers, on-the-ground reporting.

---

## 7. Thematic DNA

Recurring lenses to frame any topic:
1. **Borders & maps** — lines on paper with human consequences
2. **Power asymmetry** — who decided, who paid the price
3. **Hidden history** — the story behind the story everyone accepts
4. **Systems thinking** — one small thing revealing a giant machine
5. **The personal stake** — how it touches an ordinary viewer's life

---

## 8. Do / Don't Checklist

**Do:**
- Open with a question or anomaly, not background
- Write like you're telling a friend something amazing
- Make the narrator's discovery process part of the plot
- Pair every abstract claim with a concrete image or example
- End with meaning, not just information

**Don't:**
- Use passive voice or news-anchor neutrality
- Front-load all context before the hook
- Explain without visualizing
- Wrap up too neatly — leave a thoughtful tension
- Hide uncertainty; own it instead

---

## 9. Quick Script Template

```
COLD OPEN (0:00–0:45)
  Anomaly/question + personal obsession + stakes + tease

TITLE BEAT
  One-line thesis: "This is a story about ____."

CONTEXT (Act 2)
  "To understand this, we go back to ____."
  History compressed via maps/animation.

INVESTIGATION (Act 3)
  3–5 discovery beats, each ending in a new question.
  Include: expert clip, document/archive moment, twist.

REVEAL (Act 4)
  The answer, delivered with energy.

SO WHAT (Outro)
  Zoom out to theme. Moral tension. Direct address.
  "And that's why I can't stop thinking about ____."
```
