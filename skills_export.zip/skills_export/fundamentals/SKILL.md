---
name: fundamentals
description: >
  Triggered exclusively by the command /fundamentals [TICKER]. Produces a full interactive
  investment dashboard: financials, margins, FCF, valuation, DCF, SWOT, leadership,
  product pipeline & distribution, AI strategy & infrastructure, ESG, and political/
  lobbying exposure — all scored 1–10.
---

# /fundamentals — Stock Fundamental Analysis Skill

Produces a comprehensive, interactive investment dashboard for any publicly traded company,
based entirely on reported financials (SEC filings, earnings releases, proxy statements),
plus open web research on product pipeline, AI strategy, ESG, and political exposure.
No reliance on analyst price targets or news sentiment — pure fundamentals.

---

## Step 1 — Identify the company

Extract the ticker or company name from the user's message. If ambiguous (e.g. "analyze
Apple" could mean AAPL, or a private company), confirm with the user before proceeding.

---

## Step 2 — Research (run all searches in parallel where possible)

Pull data from SEC filings, earnings press releases, and proxy statements. Aim for at least
4 fiscal years of historical data plus the most recent quarter and forward guidance.

**Required data points to collect:**

### Income statement
- Annual revenue (4+ years) and YoY growth rates
- Gross profit and gross margin
- R&D expense and as % of revenue
- SG&A expense
- Operating income / EBIT
- GAAP net income
- Non-GAAP / adjusted net income (note the difference clearly)
- Diluted EPS (GAAP and non-GAAP)

### Profitability & margins
- Gross margin trend
- Operating margin trend
- Adjusted EBITDA and margin (if reported)
- Net margin

### Cash flow
- Operating cash flow
- Capital expenditures
- Free cash flow = OCF − capex
- FCF margin (FCF / revenue)
- FCF conversion (FCF / net income or EBITDA)

### Balance sheet
- Cash and equivalents
- Total debt (short + long term)
- Net debt = total debt − cash
- Goodwill and intangible assets
- Total assets and total liabilities
- Shareholders' equity
- Tangible book value

### Key derived ratios
- Net debt / EBITDA
- Debt / equity
- Current ratio
- Return on equity (ROE)
- Return on invested capital (ROIC) if calculable

### Valuation (at current market price)
- Market cap and enterprise value
- Trailing P/E
- Forward P/E (use guidance or consensus if available)
- EV/EBITDA
- EV/FCF
- Price/Sales
- PEG ratio (P/E ÷ expected EPS growth rate)
- Dividend yield (if applicable)

### Capital returns
- Dividends paid (history, growth streak)
- Share buybacks / repurchases
- Share count trend (dilution or reduction)

### Management & governance (from proxy DEF 14A)
- CEO name, tenure, age, background
- CFO and key operating executives
- CEO compensation structure (salary, equity, bonus)
- Say-on-pay approval rates
- Board independence (% independent directors)
- Separate chair/CEO roles
- Anti-hedging / pledging policies
- Key-man risk assessment
- Succession planning disclosures
- Total shareholder return under current leadership

### Forward guidance (most recent)
- Next quarter revenue guidance
- Full year guidance (if provided)
- Margin guidance
- Any segment-specific guidance

### ESG / Environmental data
- Carbon emissions (Scope 1, 2, 3 if disclosed) and reduction targets
- Net zero / carbon neutrality commitments and target year
- Renewable energy usage (% of total energy consumption)
- Water usage and reduction programs
- Waste and recycling metrics
- ESG ratings from major agencies (MSCI, Sustainalytics score if findable)
- Climate-related regulatory risk exposure (carbon pricing, transition risk)
- Supply chain sustainability practices
- DEI metrics (board diversity, workforce diversity disclosures)
- Any major ESG controversies, environmental violations, or fines
- ESG/sustainability report publication (yes/no, and how recent)

### Product development & future product line
Sources: company website (product pages, roadmap, investor day decks), 10-K "Business"
section, earnings call transcripts (search Seeking Alpha, Motley Fool, company IR),
press releases, patent filings (USPTO/Google Patents), CES/industry conference coverage,
trade press for the company's sector.

Collect:
- Current product/service portfolio with revenue contribution by segment (% of total)
- Products/services launched in the last 12–24 months and their early traction
- Announced or signaled future products: roadmap items, beta programs, pre-orders,
  pipeline drugs/devices, in-development platforms
- R&D spend trend and as % of revenue (cross-reference income statement)
- Patent filings velocity (recent year vs. prior years) and key patent areas
- Target client segments for new products: enterprise tier, SMB, consumer, government,
  specific industry verticals (healthcare, finance, defense, etc.)
- Geographic distribution: which markets the new products will hit first (US, EU, APAC, EM)
- Distribution channels: direct sales, channel partners/VARs, app stores, OEM bundling,
  white-label, marketplaces, retail, telco/ISP bundles
- Strategic partnerships announced that enable distribution (e.g., cloud marketplace
  listings, OEM deals, integration partnerships)
- Competitive products that the pipeline directly targets
- Time-to-market signals: stated launch windows, regulatory approvals required (FDA,
  FAA, FCC, etc.), production capacity readiness
- Total addressable market (TAM) claims for new products and how the company defines it

### AI strategy, products & infrastructure
Sources: 10-K (search for "artificial intelligence" / "machine learning" mentions),
earnings transcripts, investor day decks, dedicated AI announcement pages, partnerships
with NVIDIA / AMD / hyperscalers (AWS / Azure / GCP / OCI), AI-specific press releases,
LinkedIn for AI hiring trends, GitHub for any open-source AI work.

Collect:
- AI products currently shipping: what they are, how they're monetized (subscription
  uplift, usage-based, embedded feature, separate SKU)
- AI revenue contribution (if separately disclosed) — dollar amount and % of total
- AI products in development or beta: feature description and target launch window
- Foundation model strategy: build own models, fine-tune open-source (Llama, Mistral,
  DeepSeek), use API providers (OpenAI, Anthropic, Google), or hybrid
- Specific model partnerships (e.g., "powered by GPT-5", "Claude integration", "in-house LLM")
- Compute infrastructure: owned data centers, cloud partner (AWS/Azure/GCP/OCI),
  GPU footprint (NVIDIA H100/H200/B100/GB200 counts if disclosed, AMD MI300X, custom silicon)
- Capex commitments earmarked for AI infrastructure (most recent guidance)
- AI-specific talent: announced hires of AI leaders, AI org size, research lab presence
- Proprietary data assets: what differentiated training data the company owns (customer
  data, transaction data, industrial sensor data, medical imaging, etc.)
- Data governance: how training data is sourced, privacy posture, customer data opt-in/out
- AI safety & compliance posture: any commitments on responsible AI, EU AI Act readiness,
  bias auditing
- Patents filed in AI/ML areas (count + key areas)
- AI-related regulatory exposure: copyright lawsuits, EU AI Act classification risk,
  export control exposure (especially semiconductor / GPU restrictions)
- Customer-stated AI use cases and any quantified ROI claims from existing customers
- AI-driven cost takeout in own operations (productivity claims, headcount implications)

### Political contributions & lobbying data
Sources: OpenSecrets (opensecrets.org), FEC (fec.gov), Senate LDA filings.
Search for both the company AND its top executives (CEO, CFO) by name.

Collect:
- Total PAC contributions (most recent 2-year election cycle)
- Breakdown by party: amount to Republican candidates/committees vs. Democratic
- Top recipient politicians or committees
- Total federal lobbying spend (most recent full year)
- Top lobbying issues / bills being lobbied
- Any executive personal donations that are politically notable
- Industry trade association memberships that engage in political activity
- Any notable political controversies or regulatory relationships

**Important framing principle:** Present all political data neutrally and factually.
Do NOT characterize either party's dominance as positive or negative for investors.
DO flag policy-specific risks: e.g., "heavy lobbying on semiconductor export controls
creates regulatory dependency" is a legitimate investment risk note.

**Search strategy — run these queries:**
1. `[TICKER] annual revenue earnings income statement [current year]`
2. `[TICKER] balance sheet total debt goodwill free cash flow [current year] 10-K`
3. `[TICKER] CEO CFO executive leadership compensation proxy [current year]`
4. `[TICKER] guidance forward earnings EPS [current year]`
5. `[TICKER] valuation P/E EV/EBITDA market cap [current year]`
6. `[COMPANY NAME] PAC contributions OpenSecrets [current year]`
7. `[COMPANY NAME] lobbying spending federal [current year]`
8. `[COMPANY NAME] ESG environmental sustainability report carbon emissions [current year]`
9. `[CEO NAME] political donations FEC [current year]`
10. `[COMPANY NAME] product roadmap upcoming launches [current year]`
11. `[COMPANY NAME] new product pipeline target customers distribution`
12. `[COMPANY NAME] investor day product strategy [current year]`
13. `[COMPANY NAME] AI artificial intelligence strategy products [current year]`
14. `[COMPANY NAME] AI revenue earnings call transcript [current year]`
15. `[COMPANY NAME] NVIDIA GPU AWS Azure GCP partnership AI infrastructure`
16. `[COMPANY NAME] generative AI foundation model LLM product`

Fetch the actual SEC 8-K earnings press releases where possible — they contain the most
reliable financial tables. Cross-reference with macrotrends.net or stockanalysis.com for
historical series. For political data, fetch opensecrets.org directly where possible.

---

## Step 3 — Score each dimension (1–10 scale)

Rate every dimension on a 1–10 scale where:
- **1–3** = red (sell signal / serious concern)
- **4–6** = amber (neutral / watch)
- **7–9** = green (positive / buy signal)
- **10** = deep green (exceptional / must-buy signal on this dimension)

### Fundamental dimensions to score:
| Dimension | What to assess |
|-----------|---------------|
| Revenue growth quality | Rate, consistency, organic vs. acquired, sustainability |
| Margin structure | Gross/EBITDA/net margins vs. peers and history |
| FCF durability | FCF consistency, conversion rate, capex intensity |
| Balance sheet health | Leverage, liquidity, debt maturity, net debt/EBITDA |
| Competitive moat | Pricing power, switching costs, market position |
| Capital allocation | M&A track record, buybacks, dividends, ROIC |
| Valuation vs. fundamentals | Forward multiples vs. growth rate, PEG, DCF range |
| Risk profile | Cyclicality, concentration, regulatory, macro exposure |

### Leadership dimensions to score:
| Dimension | What to assess |
|-----------|---------------|
| CEO track record | TSR under tenure, strategy execution, crisis management |
| M&A / capital allocation | Acquisition quality and integration, return on invested capital |
| Shareholder alignment | Insider ownership, compensation structure, skin in the game |
| CFO / financial discipline | Clean reporting, leverage management, guidance accuracy |
| Governance quality | Board independence, say-on-pay, anti-pledging, clawback |
| Management depth / bench | Quality of #2 and #3 executives, org structure |
| Succession planning | Identified successors, key-man risk mitigation |
| Compensation reasonableness | Pay quantum vs. peers and performance, structure |

### ESG / Environmental dimensions to score:
| Dimension | What to assess |
|-----------|---------------|
| Carbon / climate commitment | Net zero target, credibility, progress vs. pledge |
| Emissions trajectory | Scope 1+2 trending down? Any absolute reductions? |
| Renewable energy adoption | % of energy from renewables, stated targets |
| Environmental compliance | Violations, fines, EPA/EU regulatory actions |
| Supply chain sustainability | Supplier audits, conflict minerals, labor standards |
| ESG reporting quality | Does a recent, detailed sustainability report exist? |
| DEI & social governance | Board diversity, pay equity disclosures |
| ESG controversy risk | Active litigation, greenwashing allegations, reputational events |

**ESG scoring note:** ESG score reflects investor-relevant risk, not moral judgment.
A low ESG score = higher regulatory / reputational / transition risk for the company.
A high ESG score = lower exposure to those risks. Always explain the investment
relevance, not just whether the company is "good" or "bad."

### Political / lobbying dimensions to score (investor risk lens only):
| Dimension | What to assess |
|-----------|---------------|
| Lobbying spend intensity | Total $ and as % of revenue — high spend = high regulatory dependency |
| Policy concentration risk | Is the business model dependent on favorable policy in 1–2 areas? |
| Regulatory relationship quality | Is the company ahead of, compliant with, or fighting regulators? |
| Political contribution transparency | Are donations disclosed clearly? Any legal/ethics issues? |
| Bipartisan vs. concentrated giving | Concentrated giving to one party = higher political cycle risk |
| Trade / tariff exposure | Export controls, sanctions, tariff sensitivity given contribution patterns |
| Antitrust / competition risk | Active investigations or lobby activity around competition policy |
| Geopolitical risk from political stance | International relationship risk tied to political positioning |

**Political scoring note:** Score reflects investment risk exposure only. A low score
means the company has high political dependency or concentration risk that could
affect revenue or operations if political winds shift. A high score means the
company has diversified political exposure and low regulatory cliff risk. This is
NOT a score of whether the company's political leanings are good or bad.

### Product development dimensions to score:
| Dimension | What to assess |
|-----------|---------------|
| Pipeline strength | Number, scale, and credibility of products in development |
| R&D efficiency | R&D spend % vs. peer benchmarks, output (launches/patents) per $ |
| TAM expansion | Does the pipeline open new markets or just defend existing ones? |
| Target client fit | Are new products aimed at sticky, high-LTV client segments? |
| Distribution leverage | Existing channels usable for new products, or new GTM required? |
| Time-to-market clarity | Stated timelines, regulatory path certainty, production readiness |
| Competitive differentiation | Defensible features vs. credible alternatives in pipeline |
| Execution track record | History of hitting launch dates and revenue ramp on prior new products |

**Product scoring note:** This rates the future revenue engine, not current products.
A high score means the pipeline can plausibly drive durable growth and reach attractive
client segments through workable channels. A low score means the company is either
dry on pipeline, depending on unproven channels, or chasing crowded markets.

### AI dimensions to score (investor lens):
| Dimension | What to assess |
|-----------|---------------|
| AI revenue traction | Disclosed AI revenue, growth rate, and % of total |
| AI product depth | Number of shipping AI features/products and customer pull signals |
| Model strategy fit | Build vs. buy choice rational for the company's scale and data position |
| Compute infrastructure | Adequate GPU/cloud commitments to support stated roadmap |
| Proprietary data moat | Unique training data the company owns that competitors can't replicate |
| AI talent & org | Visible AI leadership, research depth, hiring momentum |
| AI cost discipline | Capex intensity reasonable vs. monetization path — burn vs. return |
| AI regulatory/legal exposure | Copyright, EU AI Act, GPU export control, content liability risk |

**AI scoring note:** This rates how well-positioned the company is to monetize AI and
absorb AI disruption. A high score means clear product traction, sensible
build/buy/partner choices, sufficient infrastructure, and defensible data — with
manageable regulatory exposure. A low score signals either AI strategy that's all talk
no revenue, dependence on third parties that could become competitors, or material
copyright/regulatory cliff risk.

**Composite overall score** = weighted average across all rated dimensions.
Suggested weights: fundamentals 45%, leadership 20%, product development 10%,
AI 10%, ESG 7.5%, political risk 7.5%.

---

## Step 4 — Run DCF intrinsic value estimate

Use a simple 5-year DCF on free cash flow:
- **Base case**: moderate FCF growth (roughly in line with recent organic rate), 10% discount rate, 20–25× terminal FCF multiple
- **Bear case**: meaningful growth deceleration, 11–12% discount rate, 18–20× terminal multiple
- **Bull case**: acceleration of recent growth trend, 9–10% discount rate, 28–32× terminal multiple

Show the resulting per-share intrinsic value range and compare to current price.
State clearly whether the stock is: trading at a discount (margin of safety), fairly valued, or
priced for perfection (limited margin of safety).

---

## Step 5 — Build the dashboard

Use `visualize:show_widget` to render a full interactive HTML dashboard. Load the
`visualize:read_me` tool first with modules `["chart", "interactive", "mockup"]`.

**Required dashboard sections:**

### Header
- Ticker, company name, exchange
- Overall composite score (large, color-coded: red ≤4, amber 5–6, green ≥7)
- Verdict label (e.g. "Selective buy", "Hold", "Avoid", "Strong buy")
- Date and data source note

### KPI strip (5 cards)
Always include: revenue (latest FY + YoY%), EBITDA margin, FCF, net debt/EBITDA, and one
company-specific highlight (e.g. AI revenue, recurring revenue %, or TSR since IPO).

### Composite score bar
A full-width gradient bar from red (1) to green (10) with a marker at the current score.
Show "1 — Sell" and "10 — Must buy" at the ends.

### Fundamental ratings panel
Left card: all 8 fundamental dimension scores as labeled bar rows. Each bar and number
color-coded green/amber/red by score value.

Right card: Revenue & FCF trend line chart (Chart.js, 4–6 years of data).

### SWOT grid (2×2)
- Green fill: Strengths
- Red fill: Weaknesses
- Blue fill: Opportunities
- Amber fill: Threats
Each cell: 5–6 bullet points, 11px text, correct color for background.

### Leadership section
**Leadership ratings panel** — same bar-row format as fundamental ratings, all 8 leadership
dimensions scored and color-coded.

**CEO compensation chart** — stacked bar showing equity vs. cash comp for last 3 years.

**Executive profiles** — one row per key executive (CEO, CFO, COO/President):
- Initials avatar circle
- Name, title, age/tenure
- 2–3 sentence bio focused on value-relevant facts
- Tagged pills for key strengths and risks
- Individual score (1–10) displayed top-right

**Governance snapshot** — 4 metric cards: board independence, chair/CEO split,
say-on-pay %, hedging/pledging policy.

### Product development section
**Product ratings panel** — same bar-row format as fundamental ratings, all 8 product
development dimensions scored and color-coded.

**Pipeline timeline card** — vertical or horizontal timeline showing announced/expected
product launches over the next 24 months. Each item: product name, target launch
quarter/year, target client segment as a pill, and a confidence dot (green/amber/red)
reflecting time-to-market certainty.

**Revenue mix card** — donut chart of current revenue by product segment, plus a side
panel listing the top 3 pipeline products with their estimated TAM in dollars and
the client tier they target.

**Distribution channel map** — a 4–6 row table or pill cluster listing distribution
channels (direct sales, channel partners, cloud marketplaces, OEM, retail, app stores,
etc.) with a tag indicating which pipeline products will use each channel. Include
any named partners (e.g., "AWS Marketplace", "Best Buy", "Verizon bundle").

**Product risk note** — 2–3 sentence investor view: what the pipeline must deliver
for the bull case to hold, the single biggest execution risk, and whether the
distribution plan looks credible given current channel relationships.

### AI section
**AI ratings panel** — same bar-row format, all 8 AI dimensions scored and color-coded.

**AI infrastructure snapshot** — 4 metric cards showing:
1. Compute footprint (e.g., "100k+ NVIDIA H100s deployed", or "Multi-cloud across
   AWS / Azure", or "Cloud-only, no owned compute")
2. Model strategy (e.g., "In-house foundation model + open-source fine-tune", or
   "API-dependent on OpenAI/Anthropic", or "Hybrid")
3. AI capex commitment (latest stated $ figure or % of total capex earmarked for AI)
4. Proprietary data moat (e.g., "Strong — owns 20yr customer transaction data",
   or "Limited — uses public web data only")

**AI product portfolio card** — table or pill cluster listing shipping AI products
(name, monetization model, customer segment) and AI products in development (name,
target launch). Tag each with a "shipping" / "beta" / "announced" status.

**Foundation model & partnership map** — visual block showing the company's model
stack and key AI partners (chip vendors like NVIDIA/AMD, cloud providers, model
providers like OpenAI/Anthropic/Mistral, data partners). One line per relationship
with the strategic role (e.g., "NVIDIA — primary compute partner, GB200 allocation").

**AI risk note** — 2–3 sentence investor view: how much of the AI thesis is shipping
vs. announced, the most material dependency risk (chip supply, partner relationship,
data licensing, regulation), and whether the AI capex appears justified by the
disclosed revenue path.

### ESG / Environmental section
**ESG ratings panel** — same bar-row format as fundamental ratings, all 8 ESG dimensions
scored and color-coded green/amber/red.

**Environmental metrics card** — 4 metric cards showing:
1. Carbon target (e.g. "Net zero by 2040" or "No commitment")
2. Renewable energy % (or "Not disclosed")
3. ESG agency rating (e.g. "MSCI: AA" or "Sustainalytics: 18.3 Low Risk")
4. Last sustainability report year

**ESG risk summary** — a concise risk note (2–3 sentences) explaining the most
material ESG risks for this specific company and sector. Frame entirely as
investor risk, not ethics.

### Political / lobbying section
**Political risk ratings panel** — same bar-row format, all 8 political dimensions
scored and color-coded.

**Contribution breakdown chart** — horizontal stacked bar chart showing:
- PAC/corporate contributions split by party (Republican % vs. Democratic % vs. Other %)
- Use neutral colors: blue (#378ADD) for Democratic, red (#E24B4A) for Republican,
  gray (#888780) for Other/Bipartisan committees
- Label both the dollar amounts and the percentages
- Show 1–2 most recent election cycles if data available

**Lobbying spend card** — metric card showing total lobbying spend (most recent year),
YoY change, and top 2–3 lobbying issue areas as tags.

**Top recipients table** — simple table listing the top 5 political recipients of
company PAC money: Name, Party, Office/Committee, Amount. Keep this purely factual.

**Political risk note** — 2–3 sentence investor-risk interpretation:
- What policy areas does the company depend on?
- What is the risk if the political balance shifts?
- No characterization of either party as good or bad for the company.

**If political data is not found:** Show a "Data not available" state for the
contribution chart and note that the company either has no PAC, or data was not
retrievable from FEC/OpenSecrets for this search. Still complete the lobbying
spend search separately, as many companies lobby without a PAC.
1. Margin snapshot — horizontal bar chart (gross, EBITDA, FCF, R&D as %)
2. Valuation multiples — horizontal bar chart (trailing P/E, forward P/E, EV/EBITDA,
   EV/FCF, PEG ×10), color-coded: green if attractive, red if stretched
3. DCF intrinsic value — bear/base/bull per-share values vs. current price, plus
   a 2-sentence interpretation

**Chart.js rules:**
- Every canvas needs `role="img"` and `aria-label`
- Never hardcode colors that won't work in dark mode — use the hex values from the
  design system (greens: #1D9E75 / #3B6D11, reds: #E24B4A / #A32D2D, ambers: #EF9F27 / #BA7517,
  blues: #378ADD / #0C447C, purples: #7F77DD / #3C3489)
- Grid and tick colors: use `isDark` check → `rgba(255,255,255,.07)` or `rgba(0,0,0,.06)`
- Legends: disable Chart.js default, build custom HTML legends above charts
- All canvas containers: `position: relative; height: Xpx` — never set height on canvas itself

**CSS / design rules:**
- No hardcoded colors for text — always use `var(--color-text-primary/secondary)`
- No gradients except the score bar gradient (CSS `linear-gradient` only there)
- Card style: `background: var(--color-background-primary); border: 0.5px solid var(--color-border-tertiary); border-radius: var(--border-radius-lg); padding: 14px`
- Metric card style: `background: var(--color-background-secondary); border-radius: var(--border-radius-md); padding: 11px 13px`
- SWOT item text: always use 800-stop color from the same ramp as the fill
- Section dividers: `font-size: 12px; font-weight: 500; text-transform: uppercase; letter-spacing: .06em; border-bottom: 0.5px solid var(--color-border-tertiary); padding-bottom: 6px; margin: 1.5rem 0 1rem`

---

## Step 6 — Write analytical prose (outside the widget)

After the widget renders, write one substantive paragraph for each of the following:

1. **Revenue & growth** — quality of growth (organic vs. acquired), key drivers, sustainability
2. **Margin & profitability** — structural reasons for margins, GAAP vs. non-GAAP divergence if material, trajectory
3. **FCF & capital returns** — FCF durability, capex model, how cash is being returned or deployed
4. **Balance sheet** — debt context (manageable vs. concerning), goodwill/intangible risk if relevant
5. **Valuation** — whether current price is justified by fundamentals, DCF interpretation
6. **Leadership** — CEO value-add, key risks (succession, compensation), and what the team gets right and wrong

7. **Product development & pipeline** — what's actually being built, which client segments
   it can reach, the distribution machinery available to ship it, and the single biggest
   execution risk between announcement and revenue
8. **AI strategy & infrastructure** — what AI products are shipping vs. talk, the
   build/buy/partner choice and whether it fits the company's scale, the compute and
   data position behind the strategy, and the most material AI-related risk (dependency,
   regulation, or capex burn without monetization)
9. **ESG / environmental** — material environmental risks, progress vs. commitments, and
   any near-term regulatory or transition risk that could affect operations or costs
10. **Political & regulatory** — key policy dependencies, lobbying posture, contribution
    patterns as investment risk signals, and what a political shift could mean for the business

Each paragraph should be analyst-note quality: specific data points, clear mechanism, and
one named risk or watch item. No filler. Target 3–5 sentences per paragraph.

End with a **summary verdict**: one crisp paragraph stating the overall investment case —
bull case, bear case, and what the score reflects.

---

## Quality checklist

Before finalizing, verify:
- [ ] At least 4 years of revenue history in the chart
- [ ] All 8 fundamental dimensions scored
- [ ] All 8 leadership dimensions scored
- [ ] All 8 product development dimensions scored
- [ ] All 8 AI dimensions scored
- [ ] All 8 ESG dimensions scored
- [ ] All 8 political risk dimensions scored
- [ ] Product pipeline shows at least 2 named upcoming products with target client segments
- [ ] Distribution channel map names at least one specific partner or channel per pipeline product
- [ ] AI section distinguishes shipping AI products from announced ones
- [ ] AI infrastructure snapshot states compute footprint and model strategy explicitly
- [ ] If product or AI data is sparse, show "Limited disclosure" state — do not invent numbers
- [ ] Political contribution chart shows actual sourced data (or explicit "not found" state)
- [ ] Lobbying spend figure sourced and cited
- [ ] ESG section framed as investor risk, not moral assessment
- [ ] Political section framed as regulatory/policy risk, not partisan commentary
- [ ] SWOT has 5–6 items per quadrant
- [ ] At least 3 executives profiled (CEO required)
- [ ] DCF has all 3 scenarios (bear / base / bull)
- [ ] Composite score matches the weighted average of dimension scores using the
      updated weights (Fund 45 / Lead 20 / Product 10 / AI 10 / ESG 7.5 / Political 7.5)
- [ ] Overall verdict label matches the score (≤4 = avoid/sell, 5–6 = hold/neutral, 7–8 = selective buy/buy, 9–10 = strong buy)
- [ ] All financial figures cited match the source data (no hallucinated numbers)
- [ ] GAAP vs. non-GAAP distinctions are clearly noted where material

---

## Notes on common situations

**Acquisition-heavy companies (e.g. serial acquirers):**
- Distinguish organic revenue growth from acquisition-driven growth
- Flag GAAP earnings distortion from amortization of acquired intangibles
- Tangible book value is more relevant than stated book value
- Net debt / EBITDA is the right leverage metric (not D/E)

**High-growth / unprofitable companies:**
- Use EV/Revenue and EV/Gross Profit instead of P/E
- FCF burn rate and cash runway are critical metrics
- Path to profitability: when does the model inflect?
- Score "FCF durability" low but explain the growth trade-off

**Capital-intensive businesses (manufacturing, utilities, energy):**
- Capex as % of revenue is a critical input — normalize FCF for maintenance vs. growth capex
- EBITDA overstates free cash if capex is high — note this explicitly
- Asset base and replacement cost matter more for balance sheet analysis

**Financial companies (banks, insurers):**
- Standard FCF model doesn't apply — use ROE, ROA, net interest margin, efficiency ratio
- Note clearly that the DCF section is not applicable
- Focus on book value, tangible book value per share, and loan quality metrics

**Dividend / income stocks:**
- Dividend yield, payout ratio, and dividend coverage ratio are key
- Dividend growth streak and safety (FCF coverage) should be highlighted in the FCF section
- Add dividend yield to the KPI strip

---

## Output format summary

```
[One sentence framing the company and why the analysis matters now]

[Widget: full interactive dashboard]

[Revenue & growth paragraph]
[Margin & profitability paragraph]
[FCF & capital returns paragraph]
[Balance sheet paragraph]
[Valuation paragraph]
[Leadership paragraph]
[Product development & pipeline paragraph]
[AI strategy & infrastructure paragraph]
[ESG / environmental paragraph]
[Political & regulatory paragraph]

[Summary verdict paragraph]
```
