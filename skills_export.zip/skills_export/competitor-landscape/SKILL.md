---
name: competitor-landscape
description: >
  Research and map the competitive landscape around a company, product, or market. Use
  this skill whenever the user asks who a company's competitors are, how a market is
  structured, or for competitive intelligence — "who competes with Databricks", "map the
  CRM market", "competitive landscape for X", "who are the players in [space]", "what
  are X's alternatives", "how crowded is this market". Also trigger as a supporting step
  when a build-vs-buy analysis, FRD, or financial model needs a vendor/market scan.
  Produces a cited markdown report: player map by segment, positioning and pricing
  comparison, moats and switching costs, recent competitive moves, and open questions.
---

# Competitor Landscape

A structured, cited competitive-intelligence report. Useful standalone, and as the
research backbone for the buyorbuild, frd-generator, and excel-modeling skills (its
findings map directly onto Porter's-forces model variables).

## Workflow

### 1. Frame the market
Define the subject and the market boundary in one sentence ("competitors to X in [use
case], for [customer segment]"). Markets look different by segment — enterprise vs. SMB,
US vs. global — so state the frame explicitly and note when a player only competes in
part of it.

### 2. Research (6–12 searches)
- `[company] competitors` / `[company] alternatives`
- `[market category] market share`
- `[category] comparison [year]` and G2/Gartner-style category pages as leads
- Per identified player: their site/pricing page (`web_fetch`), recent funding or
  earnings, recent product launches
- `why we switched from [X] to [Y]` — migration stories reveal real switching costs
Prefer primary sources (company sites, filings, pricing pages) for facts; treat
analyst-blog rankings and SEO listicles as leads to verify, not evidence. Market-share
figures must name the research source and year.

### 3. Build the player map
Group 5–12 relevant players into tiers/segments (e.g., enterprise incumbents,
mid-market specialists, open-source, adjacent giants). For each: what they sell, target
customer, pricing model (with actual published numbers where available), approximate
scale (revenue/funding/customers — cited), and their sharpest differentiator.

### 4. Write the report
Save as `landscape-[subject-slug].md` and present.

```markdown
# Competitive Landscape: [Subject / Market]
*Date. Market frame: [one sentence]. Sources linked inline.*

## Market shape
[1 paragraph: size estimate (cited, with source and year), growth, concentration —
or an explicit statement that reliable sizing wasn't found.]

## Player map
[Table: Player | Segment | Target customer | Pricing model | Scale | Differentiator.
Every scale/pricing figure cited.]

## Positioning deep-dives
[One short paragraph per major player: how they win deals, where they lose, cited
evidence. Even-handed — every player gets a strength and a limitation.]

## Moats & switching costs
[What actually locks customers in per player: data gravity, integrations, contracts,
ecosystem. Grounded in migration stories and documented switching evidence.]

## Recent competitive moves
[Last ~12 months: launches, price changes, M&A, notable wins/losses — dated and cited.]

## Implications & open questions
[3–5 neutral observations and the questions research couldn't settle. If feeding a
build-vs-buy or model, list the variables this research pins down (prices, share,
concentration) for reuse.]

## Sources
```

## Rules
- Every quantitative claim cited with a link; unverifiable vendor marketing claims
  labeled as claims ("the company states...").
- Even-handed by construction: no player is described only positively or only
  negatively.
- Distinguish facts (pricing pages, filings) from analyst estimates and from inference.
- Note recency: this market may have moved since the newest source found — date every
  key fact.
- Append a token-usage estimate to the chat message, per the user's standing preference.
