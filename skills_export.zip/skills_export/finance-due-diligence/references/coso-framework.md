# COSO Internal Control Framework — Diligence Lens

This skill uses the COSO Internal Control–Integrated Framework as a **benchmark for
quality**, not as a formal SOX Section 404 attestation. The target company is private
and has no statutory SOX obligation — but the same framework auditors use to judge
public-company controls is a reasonable, well-understood yardstick for "how mature are
this company's financial controls," which is exactly what a diligence reader wants to
know.

Source: SOX Section 404(a) places responsibility for internal control over financial
reporting (ICFR) on management, and the COSO Internal Control–Integrated Framework
(2013) is the framework most U.S. companies use to design and evaluate ICFR, built
around five interrelated components.
(https://umbrex.com/resources/frameworks/organization-frameworks/sox-internal-control-framework-coso-based/)

Always state explicitly in the output, once, that this is a diligence-quality benchmark
applied to a private company — not a finding that the company is or isn't SOX-compliant
(it has no obligation to be).

## The five components, and what evidence to look for in a slide deck

For each component, look for *evidence* in the source material. Absence of evidence is
itself a gap worth naming — but say it that way ("no evidence of X was provided in the
materials reviewed"), not as a claim that the control doesn't exist at all. You weren't
given the company's full control environment, only a slide deck.

1. **Control Environment** — tone at the top, org structure, clear ownership.
   Look for: named CFO/controller, audit committee or board financial oversight
   mentioned, a code of conduct or governance reference.
2. **Risk Assessment** — process for identifying risks to accurate reporting.
   Look for: commentary on what could cause numbers to be wrong (customer
   concentration, FX, estimates), sensitivity/scenario notes.
3. **Control Activities** — the actual mechanics: approvals, reconciliations,
   segregation of duties. Look for: language like "reviewed by," "reconciled to,"
   approval thresholds, or any mention of a close process.
4. **Information & Communication** — how figures get reported and explained.
   Look for: variance commentary, footnotes, consistent labeling (e.g. is
   "unaudited" applied consistently, or only to some statements?), a clear period
   and currency on every page.
5. **Monitoring** — ongoing checks that controls are working.
   Look for: internal audit function, periodic management review cadence, prior
   period restatements (a sign monitoring caught something — note this neutrally).

## How to phrase a COSO-based finding

Bad (overclaims): "Acme has no internal controls."
Good (evidence-scoped): "The materials reviewed contain no reference to a reconciliation
or approval process for vendor payments (Control Activities), and no audit committee or
internal audit function is mentioned (Monitoring). This is a gap in the *evidence
provided*, not a confirmed absence of controls — recommend requesting the company's
control documentation directly."
