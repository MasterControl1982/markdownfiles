# Severity Rubric & Gap Checklist

## Severity tags

Use exactly one of: **High / Medium / Low**. Every finding gets a tag. The point of a
tag is to let a reader triage fast — don't tag everything High, and don't soften a real
quantitative breach to Medium to seem diplomatic. Objectivity means the tag follows the
rule, not the tone of the surrounding sentence.

- **High** — either (a) a quantitative threshold is breached (e.g. concentration ≥ the
  agreed threshold, statements don't reconcile, a required statement is missing
  entirely), or (b) two or more COSO components have no supporting evidence at all.
- **Medium** — a single COSO component is weak/partially evidenced, a one-off anomaly
  in an otherwise clean period, or stale/aged data (e.g. AR shown without aging, no
  way to tell how much is overdue).
- **Low** — presentation/documentation inconsistencies that don't change the financial
  picture (e.g. inconsistent "unaudited" labeling, missing period labels on one slide).

## Vendor / client concentration

Use `scripts/concentration_calc.py` rather than computing percentages by hand — see
that script's docstring for why. Default threshold is the value the user gave when this
skill was set up; if not configured, ask, don't assume.

For each AP and AR breakdown found in the source:
1. Run the calculator with the stated total (not just the sum of line items —
   if those two don't match, that mismatch is itself a Medium/High finding, see
   "Reconciliation gaps" below).
2. Anything flagged ≥ threshold goes in the report by name and dollar amount, sorted
   largest first.
3. If the source gives no vendor/client-level breakdown at all (only an aggregate AP/AR
   number), say so explicitly as a gap — "concentration risk could not be assessed; no
   vendor/client-level detail was provided" — rather than skipping the topic silently.

## Reconciliation gaps (the cross-statement check)

A real auditor's first move is checking that the three statements agree with each
other. Do this every time:

- Does ending cash on the cash flow statement match the cash balance on the balance
  sheet?
- Does net income on the P&L flow logically into retained earnings / equity on the
  balance sheet (even approximately, given a deck won't show full equity rollforward)?
- Does the change in AR/AP implied by the balance sheet match what the cash flow
  statement shows as a working-capital adjustment?

If a figure needed for this check came from an image/chart rather than an extractable
table, say so and label the figure "per visual inspection, unverified" — never present
a number read off a chart with the same confidence as one read from a table. A mismatch
between two statements is worth flagging even if one side of it is an unverified figure
— frame it as "cannot be reconciled" rather than asserting the table is right and the
chart is wrong.

## AP / AR gaps beyond concentration

- No aging buckets (0-30/31-60/61-90/90+) provided for AR or AP → Medium, note that
  collectibility/payment risk can't be assessed without it.
- Stated AP or AR total doesn't match the sum of the vendor/client detail given →
  flag explicitly with both numbers and the difference.
- No allowance for doubtful accounts or bad-debt commentary alongside AR → Low/Medium
  depending on how concentrated AR already is (a 75%-one-client AR balance with no
  allowance discussion is worse than a well-spread one).
