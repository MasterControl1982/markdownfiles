---
name: finance-due-diligence
description: "Use this skill whenever the user runs the /duediligence command, or asks to review, audit, or assess a private company's financials in a Google Drive folder of slide decks — e.g. \"run due diligence on this company's financials,\" \"check this Drive folder for red flags,\" \"look for AP/AR concentration risk,\" \"audit this deck against SOX/COSO,\" or \"find gaps in these financials.\" Use it even without the phrase \"due diligence\" — e.g. \"what's risky about this company's financials\" or \"go through Acme's board decks and tell me what's wrong.\" Produces a 4-slide pptx: an executive summary plus one deep-dive slide each for cash flow, P&L, and balance sheet. Every finding is cited to its source slide, vendor/client concentration risk is flagged against a configurable threshold, and gaps are assessed against the COSO/SOX-404 framework as a private-company diligence benchmark, not a compliance attestation."
---

# Finance Due Diligence Skill

## What this is for

A reader of this report is trying to decide whether to put money into, or do a deal
with, a private company — using whatever financial materials that company's data room
happens to contain. Slide decks are messier than clean spreadsheets: data shows up as
tables sometimes and as static chart images other times, statements don't always tie
out, and supporting detail (aging schedules, vendor breakdowns) is often just missing.
Your job is to read those materials the way a skeptical due-diligence auditor would:
note what's there, note precisely what's missing or doesn't reconcile, quantify
concentration risk, and never quietly paper over a gap by guessing a number that wasn't
actually given.

## Inputs

- **Trigger**: the `/duediligence [Drive folder link or name]` command. If no folder is
  given, ask for it before doing anything else — don't guess at a folder.
- **Source files**: Google Slides decks living in that folder. Financial data in them
  is a mix of native tables (extractable) and chart/image visuals (not extractable as
  exact figures).
- **Concentration threshold**: 20% of total AP or AR from a single vendor/client,
  unless the user gives you a different number for a given run.

## Workflow

### 1. Locate & inventory

Use the Google Drive tools to list every Slides file in the given folder. Note
filenames and last-modified dates — a gap in date coverage (e.g. a missing quarter) is
itself worth a line on the executive summary, not something to silently skip past.

### 2. Extract content from each deck

For each file:

1. Download it as `.pptx` (export from Google Slides), then run the pptx skill's
   `extract-text` against it for a fast text/table pass.
2. If a slide's `extract-text` output is suspiciously thin for its title — e.g. a slide
   titled "Cash Flow Summary" that produces no numbers — its data lives in a chart or
   picture, not text. Render that slide to an image (see the pptx skill's "Converting
   to Images" section) and read it visually with the view tool. Label anything read
   this way **"per visual inspection, unverified"** — never present a number read off a
   chart with the same confidence as one read from a table.
3. Build a running list of every line item you find: statement type, line item, value,
   period, source file, slide number, and how you got the number (table vs. visual
   estimate vs. not available). You'll cite all of this later — keep the source slide
   number attached to every figure as you go, not just at the end.

### 3. Classify into the three statements

Tag every line item as Cash Flow, Income Statement (P&L), or Balance Sheet. It's fine
if a single slide mixes more than one — classify by line item, not by slide.

### 4. Run the analysis

Read `references/risk-rating-rubric.md` before doing this step — it has the full
checklist and the reasoning behind it. In short:

- **Concentration risk**: for every AP/AR vendor or client breakdown you found, run
  `scripts/concentration_calc.py` with the configured threshold. Don't hand-compute
  these percentages — the script also catches it if a stated total doesn't match the
  sum of the line-item detail, which is a gap worth flagging on its own.
- **Cross-statement reconciliation**: does cash-flow ending cash match the balance
  sheet's cash balance? Does net income plausibly flow into equity? Do AR/AP changes
  line up with the cash flow statement's working-capital adjustments? If a number on
  one side of a check was read visually rather than extracted, say so when you flag a
  mismatch — frame it as "these two don't reconcile," not as "the chart is wrong."
- **Coverage gaps**: missing periods, missing statements, missing aging schedules
  (0-30/31-60/61-90/90+), missing vendor/client-level detail.
- **COSO/SOX-404 lens**: read `references/coso-framework.md` before writing any finding
  here. Assess each of the five components against the evidence actually present in the
  decks, and phrase gaps as "no evidence of X was provided," not as a claim that a
  control doesn't exist — you're reading a slide deck, not auditing the company
  directly.

### 5. Rate severity

Exactly one of **High / Medium / Low** per finding, per the rubric in
`references/risk-rating-rubric.md`. The tag follows the rule (quantitative breach, or
2+ uncovered COSO components = High), not the tone of the sentence around it — don't
soften a real breach to Medium to be polite.

### 6. Build the output deck

## Output: exact 4-slide structure

1. **Executive Summary** — overall picture in a few sentences, then the 3-6 most
   important findings across all three statements (mix High/Medium as warranted),
   each with its severity tag and a one-line citation. State once, here, that the
   COSO/SOX-404 references are a diligence-quality benchmark applied to a private
   company — not a finding about actual SOX compliance, since the company has no such
   obligation.
2. **Cash Flow Statement** — findings specific to cash flow: reconciliation checks,
   coverage gaps, anything visually-estimated and why.
3. **Profit & Loss (Income Statement)** — revenue/expense findings, any
   client-concentration angle that shows up in revenue rather than just AR.
4. **Balance Sheet** — AP/AR concentration results (named vendors/clients, dollar
   amounts, percentages), aging gaps, other balance sheet findings.

## Tone and citation rules

- Write in an objective auditor voice: state what was found, where, and what it means.
  Avoid hedge words ("might," "could," "possibly") unless the hedge is doing real work
  — e.g. a figure that's genuinely a visual estimate. State things plainly otherwise.
- Every individual finding ends with a citation to its source: file name and slide
  number, as a link to the source Drive file (deep-linked to the slide if the Drive URL
  supports it; otherwise link to the file and name the slide number in the sentence).
- A figure that couldn't be verified gets that noted right in the citation, e.g.
  "(unverified — read from chart image, Slide 3)."

## Design

Follow the pptx skill's design guidance in full (color palette, typography, one visual
element per slide, the required QA pass). This deck is itself implicitly a statement
about quality — a diligence report that looks sloppy undercuts its own credibility — so
treat it as a real deliverable, not a text dump with bullets. A serious, low-color-noise
palette (e.g. Midnight Executive navy/ice-blue, or Charcoal Minimal) fits the tone
better than anything playful.

## Edge cases

- No folder given with `/duediligence` → ask for it; don't guess.
- No vendor/client-level detail anywhere in the materials → state plainly that
  concentration risk could not be assessed from what was provided; don't skip the topic
  silently.
- A stated total doesn't match the sum of the line-item detail given → flag it as its
  own finding with both numbers (the calculator script surfaces this automatically when
  you pass it both).
- Materials span multiple files or quarters → infer periods from filenames/slide
  titles; if genuinely ambiguous, ask once rather than guessing silently.

## Reference files

- `references/coso-framework.md` — the five COSO components and what evidence to look
  for in slide content; read before writing any COSO-based finding.
- `references/risk-rating-rubric.md` — severity definitions and the full AP/AR/
  reconciliation checklist; read before rating anything.
- `scripts/concentration_calc.py` — run this for every concentration calculation rather
  than computing percentages by hand; its docstring explains why.
