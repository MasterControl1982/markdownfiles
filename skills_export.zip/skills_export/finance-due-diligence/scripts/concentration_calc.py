#!/usr/bin/env python3
"""
Concentration risk calculator for AP/AR vendor & client concentration.

Why a script and not LLM mental math: due diligence figures need to be
auditable and reproducible. Doing the percentage math in a deterministic
script (rather than computing it inline) means the numbers in the report
can be re-run and checked, and rounding/threshold logic is consistent
every time the skill runs.

Usage:
    python3 concentration_calc.py '<json>' [threshold_pct]

Input JSON shape:
    {
      "total": 600000,
      "entries": [
        {"name": "Vendor A", "amount": 320000},
        {"name": "Vendor B", "amount": 140000}
      ]
    }

If "total" is omitted, it's computed as the sum of entries' amounts
(use the explicit total when the source states one, since sub-ledger
detail sometimes doesn't add up to the reported total -- a gap worth
flagging in itself).
"""
import json
import sys


def calculate(data, threshold_pct=20.0):
    entries = data["entries"]
    stated_total = data.get("total")
    summed_total = sum(e["amount"] for e in entries)
    total = stated_total if stated_total is not None else summed_total

    results = []
    for e in entries:
        pct = (e["amount"] / total * 100) if total else 0
        results.append({
            "name": e["name"],
            "amount": e["amount"],
            "pct_of_total": round(pct, 1),
            "flagged": pct >= threshold_pct,
        })
    results.sort(key=lambda x: x["pct_of_total"], reverse=True)

    reconciliation_gap = None
    if stated_total is not None and abs(stated_total - summed_total) > 0.01:
        reconciliation_gap = {
            "stated_total": stated_total,
            "sum_of_detail": summed_total,
            "difference": round(stated_total - summed_total, 2),
        }

    return {
        "total_used": total,
        "threshold_pct": threshold_pct,
        "results": results,
        "flagged_count": sum(1 for r in results if r["flagged"]),
        "reconciliation_gap": reconciliation_gap,
    }


if __name__ == "__main__":
    raw = sys.argv[1]
    threshold = float(sys.argv[2]) if len(sys.argv) > 2 else 20.0
    data = json.loads(raw)
    out = calculate(data, threshold)
    print(json.dumps(out, indent=2))
