# Cost Model Reference

Full taxonomy for the Excel model. The model has 5 tabs: Assumptions, Build, Buy, Summary, Timeline. Default analysis horizon = 3 years (make it an Assumptions input so the user can change it).

## Tab: Assumptions (all blue/hardcoded inputs)

Group inputs into labeled sections. Yellow-fill the cells most likely to be changed.

### General
- Analysis horizon (years) — default 3
- Discount rate (optional, for NPV) — default 0% (off) unless user wants NPV
- Contingency % applied to build one-time — default 15%
- Annual cost inflation / vendor renewal escalation % — default 5%

### Scale (cost drivers)
- Initial user/seat count
- Annual growth % of users
- Driver type (per-seat / per-transaction / per-API-call / per-GB) — note in a comment
- Driver volume per period (if not seat-based)

### Engineering rates
- Fully-loaded cost per engineer (annual) — or hourly × 2080
- Role mix counts: senior, mid, junior, PM, design, QA (or a single blended team size)
- Optional separate rates per role

### Build effort
- Estimated build duration (months)
- Team size during build (FTEs)
- Reuse factor % from existing infrastructure (reduces effort) — from input #6
- Annual maintenance as % of build labor — default 18%
- Annual hosting/infra cost
- Annual on-call / ops cost
- Security/compliance one-time cost (from considerations #9)

### Buy
- Vendor name
- Pricing unit & unit price (e.g., $/seat/month) — SOURCE in adjacent cell
- Pricing tiers / minimum commit (if any)
- One-time implementation fee
- Integration/professional-services fee (from integration surface #8)
- Migration/onboarding cost
- Annual training cost
- Support tier annual cost
- Overage rate (if usage exceeds tier)

## Tab: Build

Rows (each year as a column, Year 0/1..N):

**One-time (Year 0)**
- Design & discovery = % of build labor (or explicit)
- Development labor = team size × duration × blended rate × (1 − reuse factor)
- QA/testing = % of dev labor
- Integration build = effort for integration surface
- Security & compliance one-time
- PM/overhead = % of total
- Contingency = contingency % × subtotal
- **Build one-time total** (formula)

**Ongoing (Year 1..N)**
- Maintenance = maintenance % × build labor, escalated annually
- Hosting/infra = annual infra × (1 + inflation)^year, scaled by user growth if usage-based
- On-call/ops
- Enhancement reserve (optional)
- **Build ongoing total per year** (formula)

**Build cumulative TCO** = one-time + sum of ongoing through year N.

## Tab: Buy

**One-time (Year 0)**
- Implementation fee
- Integration / professional services
- Migration
- Initial training
- **Buy one-time total**

**Ongoing (Year 1..N)**
- License/subscription = unit price × units, where units = seats (or driver volume) grown by annual growth %; escalate price by renewal escalation %
- Support tier
- Overage (if volume > tier)
- Recurring training
- **Buy ongoing total per year**

**Buy cumulative TCO** = one-time + sum of ongoing through year N.

## Tab: Summary (pure formulas, green cross-sheet links)
- Build TCO by year + cumulative
- Buy TCO by year + cumulative
- Annual delta and cumulative delta (Build − Buy)
- Break-even year = first year cumulative lines cross (use a formula, not eyeballed)
- Optional NPV of each if discount rate > 0

Present neutrally: show both columns equal; do not flag a "winner" cell.

## Tab: Timeline
Two milestone tracks with start month / end month (relative to today or to target launch):
- **Build track**: Discovery → Design → Development → Integration → QA/Security → Launch
- **Buy track**: Procurement/Contract → Implementation → Integration → Migration → Training → Go-live
Include the target launch date as a reference marker. These feed the side-by-side timeline slide.

## Formula discipline
- No hardcoded numbers in Build/Buy/Summary/Timeline — only references to Assumptions.
- Use SUMIFS/explicit cell refs, never magic constants.
- Format currency as $#,##0; show zeros as "-"; percentages 0.0%.
- Run recalc and confirm zero formula errors before delivery.
