# Deck Spec — 4 pages, neutral

Build with pptxgenjs (pptx skill). EXACTLY 4 content slides. Optionally one title slide is allowed but the 4 required pages below are the deliverable. Neutral palette (Charcoal Minimal or Midnight Executive). Both options always get equal visual weight — no good/bad color coding, no checkmarks vs crosses, no "winner" highlight.

Every number must come from the finished Excel model so the two reconcile.

## Slide 1 — Summary
- Header: "Build vs Buy: <Product>"
- One-line use case.
- Two equal cards/columns: **Build** and **Buy**, each showing cumulative TCO over the horizon (e.g., "3-Year TCO").
- Cost delta (Build − Buy) stated as a number, neutral wording ("Difference: $X").
- Break-even period (e.g., "Cumulative costs cross in Year 2").
- A compact table: rows = One-time, Annual ongoing, 3-Yr TCO; columns = Build | Buy.
- Footer note: "Figures driven by the linked Excel model. Estimates marked accordingly. This analysis is neutral and makes no recommendation."

## Slide 2 — Build Cost Detail
- One-time vs ongoing breakdown (bar or stacked bar from model Build tab).
- Key drivers callouts: team size, duration, blended rate, reuse factor, infra.
- Note security/compliance one-time if applicable.
- List top assumptions that move the number most (sensitivity hint, no recommendation).

## Slide 3 — Buy Cost Detail
- License/subscription scaled by the cost driver (seats/usage) over horizon.
- One-time: implementation, integration/professional services, migration, training.
- Ongoing: support tier, renewal escalation %, overage.
- Cite vendor + pricing source (URL/date) if web-sourced; label estimates.

## Slide 4 — Timelines Side-by-Side
- Single shared horizontal time axis (months from today, or calendar).
- Two stacked tracks: Build milestones and Buy milestones.
- Mark the target launch date with a vertical reference line so the gap to each track's go-live is visible.
- Neutral caption stating the elapsed time to go-live for each, no judgment.

## Neutrality checklist before export
- [ ] No slide titled or implying "Recommendation".
- [ ] No language like "we should", "better choice", "recommended".
- [ ] Build and Buy rendered in equal-weight, non-judgmental colors.
- [ ] All figures reconcile to the Excel model.
- [ ] Estimates / web-sourced figures labeled.
