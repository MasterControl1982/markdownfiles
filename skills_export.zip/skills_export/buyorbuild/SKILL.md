---
name: buyorbuild
description: Produce a neutral, side-by-side build-vs-buy cost analysis comparing building a product/feature in-house against buying a vendor solution. Use this skill whenever the user wants to evaluate, compare, or model the cost of building software in-house versus purchasing a vendor/SaaS solution — including phrasings like "build vs buy", "should we build or buy", "in-house vs vendor cost", "make vs buy analysis", "cost of building X ourselves vs buying Y", "compare building this vs licensing a tool", or any request to weigh internal engineering cost against a vendor price. Trigger even if the user does not say "build vs buy" but is clearly comparing an internal build cost to a vendor/SaaS purchase. Output is ALWAYS a 4-page PowerPoint deck (Summary, Build Cost Detail, Buy Cost Detail, Timelines Side-by-Side) PLUS a linked Excel model with editable assumptions that flow to all totals. This skill is strictly NEUTRAL — it never recommends, picks a winner, or tells the user which to choose.
---

# Build vs Buy Analysis (buyorbuild)

Produce a neutral, decision-support package comparing the cost of **building in-house** vs **buying a vendor solution**. Two deliverables, always: a **4-page PowerPoint deck** and a **linked Excel model** whose assumptions drive every total.

## Core principle: NEUTRALITY

This skill is a calculator and presenter, not an advisor. It NEVER recommends, never says "we recommend building/buying", never declares a winner, never adds a "Recommendation" slide, and never weights one option as better. It presents costs, timelines, and trade-offs side by side and lets the numbers speak. If totals clearly favor one side, state the numbers plainly without editorializing. If the user asks "so which should we pick?", restate the comparison and remind them the analysis is neutral by design; surface the decision factors (cost delta, timeline delta, strategic considerations they provided) but let them decide.

## Step 1 — Gather inputs (ask all 10, then proceed)

Ask the user for the following. Present them as a numbered list in ONE message so the user can answer in bulk. If the user already supplied some in their request, don't re-ask — confirm and fill gaps. For anything left blank, make a clearly-labeled reasonable assumption and mark it in the model (yellow/blue input cell) so they can change it.

1. **Product** — what is being built/bought (the system, feature, or capability).
2. **Use case** — what problem it solves and for whom.
3. **Scale** — user count, transaction/seat volume, and the primary **cost driver** (per-seat, per-API-call, per-GB, per-transaction, etc.).
4. **Launch date** — target go-live; used to derive the build timeline feasibility and any "cost of delay" framing (neutral, just timing).
5. **Engineering rates** — fully-loaded cost per engineer (annual or hourly) and any role mix (senior/mid/junior, PM, design, QA). If only a single blended rate is given, use it.
6. **Existing related infrastructure** — platforms, services, data stores, auth, CI/CD, or prior internal work that reduces build effort.
7. **Vendor under consideration and price** — name and pricing (list, quoted, or tiered). **If not supplied, SEARCH THE WEB** for the leading vendors in that category and their public pricing; cite sources and label figures as estimates.
8. **Integration surface** — systems the solution must connect to (APIs, SSO, data pipelines, internal tools); drives both build effort and vendor integration cost.
9. **Considerations** — regulatory/compliance, security, data residency, procurement, or contractual constraints (e.g., HIPAA, SOC 2, GDPR, FedRAMP). These appear as factors, not as scored recommendations.
10. **Related files** — any RFPs, vendor quotes, architecture docs, prior estimates, or spreadsheets to ground the model. Read them if provided.

When the vendor or its pricing is missing, run web searches (vendor pricing pages, comparison sites) and record each figure's source URL and date in the Excel model's Sources column. Always mark web-derived numbers as estimates.

## Step 2 — Build the cost model (do this BEFORE the deck)

Read `references/cost-model.md` for the full line-item taxonomy and formula structure. Then build the Excel model FIRST — the deck pulls its numbers from the model so they must agree exactly.

The model has these tabs:
- **Assumptions** — every editable input as a blue/hardcoded cell (rates, scale, vendor price, growth, horizon, contingency %). This is the only place numbers are typed. Yellow background on the key cells the user is most likely to change.
- **Build** — one-time (design, development, QA, integration, security/compliance, PM) + ongoing (maintenance %, hosting/infra, on-call, future enhancements) over the analysis horizon. All cells reference Assumptions.
- **Buy** — one-time (implementation, integration, migration, training) + ongoing (license/subscription scaled by the cost driver, support tier, overage, renewal escalation) over the same horizon.
- **Summary** — total cost of ownership for each option per year and cumulative, the delta, and break-even period. Pure formulas, no hardcodes.
- **Timeline** — milestone start/end for both options feeding the side-by-side slide.

Use the **xlsx skill** (`/mnt/skills/public/xlsx/SKILL.md`) to write the file. Follow its color conventions strictly: blue = inputs the user changes, black = formulas, green = cross-sheet links. Every total MUST be a formula chain back to Assumptions so that changing one assumption updates the whole model. Deliver with ZERO formula errors and run `scripts/recalc.py` to recalc before handoff. Default the analysis horizon to a 3-year TCO unless the user specifies otherwise.

Use a consistent analysis horizon (default 3 years), and keep the same horizon across Build, Buy, Summary, and Timeline.

## Step 3 — Build the 4-page deck

Use the **pptx skill** (`/mnt/skills/public/pptx/SKILL.md`), creating from scratch with pptxgenjs. EXACTLY four content pages, in this order:

1. **Summary** — the product/use case in one line, both TCO totals (cumulative over horizon), the cost delta, break-even period, and a compact 2-column comparison (Build | Buy) of headline figures. No recommendation.
2. **Build Cost Detail** — one-time vs ongoing breakdown, key drivers (headcount, duration, infra), and the assumptions that move the number most. Mirror the Excel Build tab.
3. **Buy Cost Detail** — license/subscription scaled by the cost driver, implementation/integration, support, renewal escalation. Mirror the Excel Buy tab. Cite vendor pricing source if web-sourced.
4. **Timelines Side-by-Side** — a horizontal timeline comparing Build milestones vs Buy milestones against the target launch date. Show both on the same time axis so the gap is visible.

Pull every number from the finished Excel model so the two artifacts reconcile. Pick a clean, neutral palette (e.g., Charcoal Minimal or Midnight Executive) — use a single neutral accent and DO NOT color-code one option as "good" and the other as "bad" (avoid red-for-buy / green-for-build type signaling). Keep both options visually equal weight to preserve neutrality.

## Step 4 — Deliver

Save both files to `/mnt/user-data/outputs/`, name them clearly (e.g., `build_vs_buy_<product>.pptx` and `build_vs_buy_<product>_model.xlsx`), and present them together. In the chat summary, restate the headline totals and the delta in neutral language, note which figures are estimates/assumptions, and remind the user they can change any assumption in the Excel model to see totals update. Do not append a recommendation.

## Reference files
- `references/cost-model.md` — full line-item taxonomy, formulas, and the Excel tab/column layout.
- `references/deck-spec.md` — exact content and layout for each of the 4 slides.
