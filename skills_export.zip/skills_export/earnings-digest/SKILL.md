---
name: earnings-digest
description: >
  Produce a post-earnings briefing for any publicly traded company's latest (or a
  specified) quarterly or annual report. Use this skill whenever the user asks about a
  company's earnings, results, or quarter — including phrasings like "how did NVDA's
  earnings go", "summarize AAPL's quarter", "did X beat", "earnings recap for Y",
  "what did management say on the call", or "/earnings [TICKER]". Trigger even if the
  user doesn't say "earnings" but is clearly asking about a company's just-reported
  results or guidance. Produces a dated markdown briefing: headline results vs. prior
  guidance/consensus, segment and KPI deltas, guidance changes, management commentary
  themes, and updated watch items — every figure cited to a source link.
---

# Earnings Digest

A two-minute, citation-backed read on a company's most recent reported quarter. This is a
*reporting* skill, not a valuation skill — for a full company dashboard use
`/fundamentals`; for macro trade ideas use the investment-thesis skill.

## Workflow

### 1. Identify company and quarter
Extract ticker/company and the period. Default to the **most recently reported** quarter.
If the company hasn't reported recently, say so, give the next expected report date, and
digest the last available quarter instead.

### 2. Research (4–7 searches)
Prioritize primary sources: the company's earnings press release and IR page, the 10-Q/10-K
or 8-K, the earnings-call transcript, then quality coverage (Reuters, CNBC, Bloomberg).
Query patterns: `[ticker] earnings results`, `[ticker] Q[N] [year] press release`,
`[ticker] earnings call transcript`, `[ticker] guidance [year]`. Use `web_fetch` on the
press release to get exact figures rather than relying on snippets.

### 3. Extract the core dataset
For the quarter: revenue, EPS (GAAP and non-GAAP, note the gap), operating income/margin,
FCF if disclosed, each reported segment's revenue and growth, and the company's own KPIs
(e.g. DAUs, backlog, net retention, deliveries). Capture **prior guidance** and, where
reported by credible coverage, the consensus estimate — label consensus figures as
secondhand. Capture **new guidance** verbatim ranges.

### 4. Write the digest
Save to `earnings-[ticker]-[quarter].md` in the outputs directory and present it.

```markdown
# [Company] ([TICKER]) — [Q_ FY__] Earnings Digest
*Reported [date]. Generated [date]. Sources linked inline.*

## TL;DR
[2–3 sentences: beat/miss/in-line vs. guidance and consensus, the one number that
mattered, and the stock's reported reaction if covered.]

## Headline results
[Small table: metric | result | prior guidance | consensus (if available) | YoY. Every
row cited.]

## Segments & KPIs
[One bullet per segment/KPI with growth rate and a one-line driver, cited.]

## Guidance
[New guidance vs. prior, verbatim ranges, and whether it implies acceleration or
deceleration. If none given, say so.]

## Management commentary themes
[3–5 paraphrased themes from the call — demand, margins, capex, buybacks, risks. Quote
at most one short phrase (<15 words) per source; paraphrase everything else.]

## Watch items for next quarter
[2–4 concrete things the next report will confirm or refute.]

## Sources
[Linked list, primary sources first.]
```

## Rules
- **Every figure cited with a link.** Distinguish company-reported numbers from
  consensus/coverage-derived ones.
- Beat/miss language must name the benchmark ("beat its own guidance", "missed the
  consensus estimate reported by X") — never a bare "beat".
- GAAP vs. non-GAAP differences stated whenever material.
- No buy/sell/hold language and no price targets. End the file with a one-line
  "Informational summary, not investment advice." disclaimer.
- Quiet quarters are fine: if results were in line and news was thin, a short digest
  beats a padded one.
- Append a brief token-usage estimate to the chat message (not the file), per the user's
  standing preference.
