---
name: investor-stake-tracker
description: >
  Research and report on ANY corporate investor's or fund's recent equity investments,
  stakes, and exits — Berkshire Hathaway, SoftBank, Microsoft, Alphabet, a16z, Tiger
  Global, sovereign funds, or any active acquirer/investor the user names. Use this
  skill whenever the user asks what a company or fund has been investing in, buying
  stakes in, or selling — "what has SoftBank invested in lately", "Berkshire's recent
  moves", "track Microsoft's AI investments", "13F changes for [fund]", "run the
  [investor] tracker" — for any investor. (The dedicated nvidia-investment-tracker skill
  covers NVIDIA specifically; use this one for everyone else, or when comparing multiple
  investors.) Produces a dated markdown briefing of new positions, follow-ons, and exits
  over a defined lookback window.
---

# Investor Stake Tracker

Generalized version of the NVIDIA tracker: a dated, citation-backed briefing on a named
investor's recent dealmaking. Same discipline — verify before reporting, be honest about
quiet periods, never manufacture activity.

## Workflow

### 1. Establish investor and window
Extract the investor name. Default lookback: **last 30 days** (these trackers run less
often than weekly for most investors); use the user's window if given. State the exact
window at the top of the report. If the user names multiple investors, produce one
report with a section per investor.

### 2. Research (4–8 searches per investor)
Short queries, then confirm specifics:
- `[investor] investment [month year]`
- `[investor] stake acquired`
- `[investor] funding round led`
- `[investor] sells stake` / `[investor] exit`
- `[investor] 13F` (quarterly, for US public holdings — note 13Fs lag ~45 days)
Prioritize primary sources: the investor's own announcements, SEC filings (13F, 13D/G,
8-K), portfolio-company press releases, then Reuters/Bloomberg/CNBC/FT. Treat
"stocks-to-buy" aggregators only as leads. `web_fetch` full articles when a snippet is
ambiguous on size, date, or whether the deal is new.

### 3. Filter, dedupe, verify
Only deals **announced or materially updated within the window**. Large positions get
re-reported constantly — don't list old news as new. For each deal confirm:
counterparty (+ ticker if public), amount or "undisclosed", announcement date, and type
(new / follow-on / exit / reduction). Distinguish committed capital from "up to"
structures. If a deal can't be confirmed by a credible source, leave it out; "no major
new deals this window" is a valid, correct answer.

### 4. Write the report
Save as `[investor-slug]-stakes-YYYY-MM-DD.md` and present it.

```markdown
# [Investor] Stake Tracker — [Window]
*Generated [date]. Sources linked inline.*

## TL;DR
[1–3 sentences: deal count, total disclosed dollars, single most notable move — or a
plain statement that it was quiet.]

## New investments this window
[Bullet per deal: **Company (TICKER)** — amount, deal type, one line on what they do and
the strategic logic reported. Source link. If none: say so.]

## Follow-ons & material updates
## Exits / reductions
## Context worth noting
[1–2 neutral sentences: pace vs. prior periods, sector concentration, any widely
reported critique — attributed, not endorsed.]

## Sources
```

## Rules
- Every deal cited with a link; every claim traceable.
- 13F-derived holdings are point-in-time and lagged — label the as-of quarter.
- Informational, not investment advice — one-line disclaimer at the foot of the file.
- Independent runs: recompute the window fresh each time; cross-reference a prior report
  only if the user supplies it.
- Append a token-usage estimate to the chat message, per the user's standing preference.
