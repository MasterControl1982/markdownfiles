---
name: filing-analyzer
description: >
  Deep-read a specific SEC filing — 10-K, 10-Q, 8-K, S-1, or proxy (DEF 14A) — and
  produce a structured, cited analysis: what changed, what management emphasized, and
  what the footnotes reveal. Use this skill whenever the user asks to analyze, summarize,
  or find red flags in a filing — "read AAPL's 10-K", "what changed in the risk factors",
  "analyze this 8-K", "go through the proxy", "what's buried in the footnotes", "S-1
  breakdown for [company]" — or uploads/links a filing document. For a whole-company
  dashboard use /fundamentals; this skill goes deep on ONE document.
---

# Filing Analyzer

A skeptical, structured read of one SEC filing. The value is in *changes and omissions*
— what's new vs. the prior filing, what management chose to emphasize, and what the
notes disclose that the headline numbers don't.

## Workflow

### 1. Obtain the filing
If the user uploaded it, read it (consult the pdf-reading skill for PDFs). Otherwise
search SEC EDGAR (`[company] 10-K site` style queries, then `web_fetch` the filing index
and document). Confirm you have the right company, form type, and period before
analyzing. For change analysis, also fetch the **prior comparable filing** (last year's
10-K, prior quarter's 10-Q) when accessible.

### 2. Read by form type
- **10-K/10-Q**: MD&A drivers and language shifts; risk-factor additions/deletions/
  rewordings vs. prior filing; segment detail; liquidity and debt maturities; legal
  proceedings; footnotes — revenue recognition, leases, contingencies, related-party
  transactions, off-balance-sheet items, goodwill/impairment, share-based comp.
- **8-K**: the triggering item number and what it legally signifies; plain-English
  translation of the event; what's *not* said.
- **S-1**: business model and unit economics as disclosed, use of proceeds, dual-class
  structure, insider lockups, the frankest risk factors.
- **Proxy (DEF 14A)**: compensation structure vs. performance, incentive metrics,
  related-party items, board independence, notable shareholder proposals.

### 3. Write the analysis
Save as `filing-[ticker]-[form]-[period].md` and present.

```markdown
# Filing Analysis: [Company] [Form] — [Period]
*Filed [date]. Source: [EDGAR link]. Generated [date].*

## What this filing is
[2–3 sentences of plain-English context.]

## Headline numbers
[Compact cited table if a financial filing.]

## What changed
[The most valuable section: new/removed/reworded risk factors, MD&A tone and driver
shifts, new footnote disclosures — each with the section reference (e.g., "Item 1A,
p. 23") and, where a prior filing was compared, the before/after in paraphrase.]

## Footnote findings
[3–6 items a headline reader would miss, each with location and why it matters.
Phrase as evidence: "the filing discloses X", not "the company is hiding X".]

## Management's emphasis
[What the MD&A leads with and repeats — paraphrased themes, ≤1 short quote per source.]

## Open questions
[What the filing doesn't answer; what to check next (call transcript, prior filings).]

## Sources
```

## Rules
- Cite everything: EDGAR link plus item/section (and page where available) for each
  finding.
- Findings-not-accusations voice: report disclosures and gaps; characterize risk, never
  allege wrongdoing.
- Paraphrase; maximum one sub-15-word quote per source document.
- Distinguish "not disclosed in this filing" from "does not exist".
- Large filings: read selectively by section — don't attempt a linear read of 300 pages.
- One-line footer disclaimer: informational analysis, not investment or legal advice.
- Append a token-usage estimate to the chat message, per the user's standing preference.
