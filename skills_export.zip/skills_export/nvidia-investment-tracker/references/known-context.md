# NVIDIA Known Investment Context (baseline as of late May 2026)

This is a reference snapshot to help distinguish **genuinely new** deals from **old news being re-reported**. It is NOT exhaustive and will go stale — always confirm current status with fresh web search. Treat anything here as "already known" unless a search shows a material in-window change.

## Major standing positions (already announced — do not report as "new")

- **OpenAI** — ~$30B commitment announced earlier in 2026. NVIDIA's single largest bet, roughly three-quarters of its 2026 AI investment budget. Private.
- **Intel (INTC)** — ~$5B stake announced September 2025; value appreciated dramatically (reported worth ~$25B+ in early 2026). A huge return, frequently re-reported.
- **CoreWeave (CRWV)** — ~$2B initial position (Jan 2025), reported valued ~$4.4B and a large share of Nvidia's listed equity portfolio.
- **Corning (GLW)** — up to ~$3.2B, optical fiber / data center.
- **IREN (IREN)** — up to ~$2.1B, data center operator.
- **Marvell (MRVL)** — ~$2B stake.
- **Nebius Group (NBIS)** — ~$2B, AI cloud / European data centers.
- **Synopsys, Coherent, Lumentum** — part of a string of ~$2B bets in early 2026.
- **Anthropic** and **xAI** — participated in large private funding rounds in early 2026.

## Known exits (already reported — do not report as "new")

- Sold its stake in **Applied Digital (APLD)** in Q4 2025.
- Sold its stake in **Arm Holdings (ARM)** in Q4 2025.
- Earlier sold its stake in **Serve Robotics (SERV)** (still a partner; Jensen praised them at CES 2026).

## Framing the user may find useful

- NVIDIA committed **$40B+ to AI equity bets in 2026** alone (per CNBC/FactSet), on top of ~$17.5B into private companies in the prior fiscal year (per its 10-K).
- Analysts (e.g. Wedbush) describe much of this as a **"circular investment" theme** — Nvidia funds companies that then buy Nvidia chips. Supporters frame it as building a competitive moat.
- Investments are mostly **minority positions** and small relative to Nvidia's ~$200B cash, so they don't strain the balance sheet. CFO Colette Kress framed them as ensuring compute capacity gets built around Nvidia hardware.

## How to use this file

When a search surfaces a deal, check it against this list first. If it's here, it's old — only include it if there's a material in-window update (new tranche, large valuation move, partial sale). If it's not here, it's a candidate for "new this window" — verify the date and source before including.
