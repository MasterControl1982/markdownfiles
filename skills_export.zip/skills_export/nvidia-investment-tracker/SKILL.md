---
name: nvidia-investment-tracker
description: Research and report on NVIDIA's recent equity investments, stakes, and venture deals. Use this skill whenever the user wants a weekly or periodic update on what companies NVIDIA has invested in, taken a stake in, or exited — including phrasings like "what did Nvidia invest in", "Nvidia's recent stakes", "Nvidia AI investments this week", "Nvidia portfolio update", or any scheduled/recurring run that tracks NVIDIA's dealmaking. Trigger this even when the user just says "run the Nvidia tracker" or asks for the latest on Nvidia's investment activity. Produces a dated markdown briefing of new and notable investments over a recent window.
---

# NVIDIA Investment Tracker

Produce a concise, dated briefing of NVIDIA's recent equity investments — new stakes, follow-on rounds, multi-billion-dollar public-company deals, private/venture rounds, and notable exits — over a defined lookback window (default: the last 7 days, since this is designed to run weekly).

## Why this exists

NVIDIA is one of the most active corporate investors in the AI ecosystem, taking minority positions in customers, suppliers, and partners up and down the AI stack. These moves are market-moving and frequently signal where NVIDIA sees the AI value chain heading. The goal is a reliable, repeatable briefing the user can read in two minutes each Friday.

## Workflow

### 1. Establish the date window

Compute the lookback window from the current date. Default to the **last 7 days** for a weekly run. If the user specifies a different window ("last month", "since the last run"), use that instead. State the exact window (e.g., "May 19–26, 2026") at the top of the report so it's unambiguous.

### 2. Research with web search

Run **4–7 searches** to get good coverage. Don't rely on a single query. Effective query patterns (keep them short, 2–5 words):

- `Nvidia investment [current month year]`
- `Nvidia stake deal` (then filter by recency)
- `Nvidia new investment announced`
- `Nvidia venture funding round`
- `Nvidia sells stake` (to catch exits)
- `Nvidia 13F filing` (quarterly — catches disclosed public holdings)
- Company-specific follow-ups when a deal surfaces, to confirm size and date

Prioritize **primary and high-quality sources**: NVIDIA press releases, SEC filings (13F, 8-K), CNBC, Reuters, Bloomberg, company announcements. Treat aggregators and "stocks to buy" content as secondary — use them as leads, then confirm the underlying deal.

Use `web_fetch` to read full articles when a search snippet is ambiguous about deal size, date, or whether the investment is new vs. previously announced.

### 3. Filter to the window and dedupe

Only include deals **announced or materially updated within the window**. NVIDIA's large bets (e.g., OpenAI, Intel) get re-reported constantly — don't list an old deal as new just because an article this week mentioned it. If an older position had a material change in the window (large follow-on, big valuation move, partial sale), include it and clearly label it as an update, not a new position.

### 4. Verify before reporting

For each deal, confirm: (a) the **counterparty company** and ticker if public, (b) the **dollar amount** or that it's undisclosed, (c) the **date** of announcement, (d) whether it's a **new position, follow-on, or exit**. If you can't confirm a deal happened within the window from a credible source, leave it out rather than guess. It's better to report "no major new deals this week" than to manufacture activity.

### 5. Write the report

Save to a dated markdown file: `nvidia-investments-YYYY-MM-DD.md`. Use the template below. Then present it with `present_files`.

## Report template

ALWAYS use this exact structure:

```markdown
# NVIDIA Investment Tracker — [Window, e.g. "Week of May 19–26, 2026"]

*Generated [date]. Sources linked inline.*

## TL;DR
[1–3 sentences: how many new deals, total disclosed dollars this window, the single most notable move. If quiet, say so plainly.]

## New investments this window
[For each — bullet with: **Company (TICKER)** — amount, deal type, one line on what they do / why Nvidia cares. Link the source. If none: "No newly announced positions this window."]

## Follow-ons & material updates
[Existing positions with a notable change in-window — added capital, big valuation move, partial sale. If none, omit or state "None."]

## Exits / reductions
[Stakes Nvidia sold or trimmed in-window. If none, state "None reported."]

## Context worth noting
[Optional: 1–2 sentences of framing — e.g. the "circular investment" critique, pace vs. prior periods, or sector concentration. Keep it short and neutral.]

## Sources
[Bulleted list of the primary sources used, with links.]
```

## Style rules

- **Cite every factual claim with a link.** Each deal needs a source URL. This is a recurring report the user may act on, so traceability matters.
- Lead with the most recent and most material news.
- Keep it skimmable — this is a two-minute read, not an essay. Bullets for deals, prose only for the TL;DR and context.
- Be honest about quiet weeks. A short, accurate report beats a padded one. Manufacturing significance erodes the report's value over time.
- Distinguish clearly between **committed/announced** capital and **option/"up to"** figures (Nvidia often structures deals as "up to $X").
- This is informational, not investment advice. Include a one-line disclaimer at the foot of the report.
- Append a brief token-usage estimate at the end of your chat message (not in the file), per the user's standing preference.

## Notes on recurring runs

This skill is designed to be scheduled weekly (Fridays). Each run is independent — always recompute the window from the current date and research fresh. Don't assume continuity with a prior run's findings unless the user provides the previous report. If the user does provide the last report, you can cross-reference it to avoid re-listing deals and to flag what's genuinely new.

See `references/known-context.md` for a baseline of NVIDIA's major standing positions, so you can quickly tell "new this week" from "old news being re-reported."
