---
name: thesis-monitor
description: >
  Re-check a previously written investment thesis, memo, or trade idea against what has
  actually happened since — what's confirmed, what broke, what's unresolved. Use this
  skill whenever the user provides or references a prior thesis/memo/idea and asks to
  update, re-check, revisit, or monitor it — "is my NVDA thesis still intact", "check
  this thesis against the news", "update the memo from last month", "did the catalysts
  play out", "what's changed since I wrote this" — including scheduled/recurring
  thesis-review runs. Pairs with the investment-thesis and investment-memo skills:
  they create the document, this skill audits it against reality.
---

# Thesis Monitor

An honest scorecard for a past thesis. The discipline that matters: evaluate the
original claims *as written* — no retrofitting the thesis to match what happened, and
no grading on vibes.

## Workflow

### 1. Ingest the original thesis
From an uploaded/pasted document, a prior file, or past chats (if the user references an
earlier conversation and past-chats search is available, use it). Extract into a claim
list: each **falsifiable claim**, each **named catalyst with timing**, each **stated
risk/theory-killer**, any **conviction score**, and the **date written**. If the
original is too vague to extract claims, say so — that's itself the main finding.

### 2. Research what happened
For each claim/catalyst/risk, search the period since the thesis date: price and
fundamental developments for named instruments, whether catalysts occurred and how,
whether any theory-killer fired. Cite everything. Distinguish "the claim was
confirmed/refuted" from "no evidence either way yet".

### 3. Score the claims
Per claim, one status: **Confirmed / Refuted / Partially played out / Unresolved**, each
with 1–2 cited sentences of evidence. Then, separately, the outcome: what the named
instruments actually did since the thesis date (cited levels, with the caveat that a
thesis can be right for the wrong reasons and vice versa — grade the *reasoning* and the
*result* as two different things).

### 4. Write the update
Save as `thesis-check-[slug]-YYYY-MM-DD.md` and present.

```markdown
# Thesis Check: [Original title] — as of [date]
*Original dated [date]. Elapsed: [n weeks/months]. Sources linked inline.*

## Verdict in one paragraph
[Reasoning intact / partially intact / broken — and whether the outcome agreed.]

## Claim scorecard
[Table: original claim (paraphrased) | status | evidence (cited).]

## Catalysts
[Each named catalyst: occurred? on time? market reaction? Cited.]

## Risks & theory-killers
[Which fired, which are live, any new risk the original missed.]

## What the original got most right / most wrong
[One honest paragraph each.]

## Standing questions
[What the next check should watch, with expected dates where known.]
```

## Rules
- Grade claims as written on the original date — quote the claim's substance
  (paraphrased) before scoring it, so the scoring is auditable.
- Reasoning vs. outcome are scored separately and labeled as such.
- Every evidence sentence cited with a link; "unresolved" is a valid status — don't
  force verdicts.
- No new trade recommendations; if the user wants a refreshed thesis, hand off to the
  investment-thesis skill.
- One-line footer: informational review, not investment advice.
- Append a token-usage estimate to the chat message, per the user's standing preference.
