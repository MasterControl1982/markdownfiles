---
name: investment-memo
description: >
  Produce a concise, IC-style investment memo document on a company, deal, or thesis —
  the kind circulated before an investment-committee discussion. Use this skill whenever
  the user asks for an investment memo, one-pager, IC memo, deal memo, research note, or
  a written write-up of a stock or investment idea — "write me a memo on NVDA", "turn
  this analysis into a one-pager", "IC memo for this deal", "research note on X I can
  share". Trigger even without the word "memo" when the user wants a shareable written
  document synthesizing investment research (as opposed to a dashboard — that's
  /fundamentals — or trade ideas — that's investment-thesis). Output is a markdown file
  by default, or .docx when the user wants a formal document to send.
---

# Investment Memo

Synthesizes research into a disciplined, balanced memo. The memo's job is to make a
committee's discussion sharper — it presents the strongest honest version of both the
bull and bear case with cited evidence, and it never issues a buy/sell verdict.

## Workflow

### 1. Scope
Identify the subject (ticker/company/deal) and the audience/formality. If the current
conversation already contains research (e.g., a `/fundamentals` run or an
investment-thesis output), build from it and only fill gaps — don't redo the research.
Ask at most one clarifying question, and only if the subject itself is ambiguous.

### 2. Research gaps
Search as needed for: current business snapshot, latest reported financials, valuation
at current price, the 2–3 strongest publicly argued bull points, the 2–3 strongest bear
points, and any pending catalyst (product cycle, regulatory decision, earnings date).
Primary sources first; every figure gets a link.

### 3. Write the memo (1–2 pages)

```markdown
# Investment Memo: [Company (TICKER)]
**Date:** | **Prepared by:** AI-assisted draft | **Status:** For discussion

## Summary
[3–5 sentences: what the company does, the core debate in one line, current valuation
context, and the key catalyst/timeline. No conclusion about what to do.]

## Business & financial snapshot
[Compact paragraph + small table: revenue & growth, margins, FCF, net debt, valuation
multiples — cited.]

## Bull case
[3 numbered arguments, each: the claim, the cited evidence, and what would confirm it.]

## Bear case
[3 numbered arguments, same structure and same rigor — this section must be as strong
as the bull case, not a strawman.]

## Valuation context
[Where multiples sit vs. the company's own history and named peers, cited. What growth
the current price appears to assume, framed as arithmetic, not prediction.]

## Key risks & catalysts
[Table: item | direction | timing | what to watch.]

## Questions for the committee
[3–5 genuine open questions the memo cannot settle — this is the honest frontier.]

## Sources
```

End the file with: "AI-assisted draft for discussion. Informational analysis, not
investment advice. Figures should be independently verified before any decision."

### 4. Deliver
Markdown by default. If the user asked for Word or a formal deliverable, read the docx
skill (`/mnt/skills/public/docx/SKILL.md`) first and produce .docx. Present the file.

## Rules
- **Symmetric rigor**: never let the bull case run three paragraphs and the bear case
  three sentences (or vice versa). If evidence for one side is genuinely thin, say that
  explicitly rather than padding.
- Every factual claim cited with a link; inference labeled as inference.
- No recommendation, rating, price target, or position sizing — the "Questions for the
  committee" section replaces a verdict.
- Distinguish company-reported figures from consensus or third-party estimates.
- Append a token-usage estimate to the chat message, per the user's standing preference.
