---
name: macro-weekly-brief
description: >
  Produce a dated weekly markets and macro briefing: what moved, why, and what's on the
  calendar next week. Use this skill whenever the user asks for a market recap, weekly
  brief, macro update, "what happened in markets this week", "market summary", "weekly
  wrap", "what's moving markets", or any scheduled/recurring market briefing run —
  even if they just say "run the weekly brief". Covers equities, rates, FX, commodities,
  and the 3–5 macro stories of the week, plus a week-ahead calendar. Every figure cited.
  For trade ideas built on these events use the investment-thesis skill; this skill
  reports, it does not recommend.
---

# Macro Weekly Brief

A two-minute, citation-backed read on the week in markets. Designed to run weekly
(e.g., Friday after the US close) but works for any window the user names.

## Workflow

### 1. Window
Default: the current trading week (Mon–Fri, using today's date). State the exact dates
at the top. If the user asks mid-week, cover week-to-date and say so.

### 2. Research (6–10 searches)
- `stock market this week` / `markets weekly recap`
- `S&P 500 Nasdaq weekly performance`
- `treasury yields this week` and `10 year yield`
- `dollar index oil gold this week`
- `[the week's dominant story] markets` — one focused follow-up per major story
- `economic calendar next week`
Prefer primary/quality sources: exchange data, Reuters, Bloomberg, CNBC, FT, central
bank releases. `web_fetch` a full recap article rather than stitching snippets. Pull
level + weekly % change for: S&P 500, Nasdaq, Dow (or user's regional indices), US 10Y
yield, DXY, WTI/Brent, gold, and BTC if it was a story.

### 3. Write the brief
Save as `macro-brief-YYYY-MM-DD.md` and present.

```markdown
# Weekly Market Brief — [Mon date]–[Fri date]
*Generated [date]. Sources linked inline.*

## Scoreboard
[Table: asset | close/level | weekly change. Every row cited.]

## The 3–5 stories that mattered
[One short paragraph each: what happened, the market reaction, and the open question.
Attribute interpretations to their sources ("Reuters reported traders attributed...")
rather than asserting causality as fact.]

## Rates & FX
[2–4 sentences: curve moves, notable central bank actions/speech, major pairs.]

## Commodities
[2–3 sentences on the movers.]

## Week ahead
[Bulleted calendar: date — event (CPI, FOMC, major earnings) — why it matters, cited.]
```

## Rules
- Every number cited with a link; state the as-of timestamp for quotes since markets
  move after sources publish.
- Correlation-not-causation discipline: market "because" narratives are attributed to
  the reporting source, not asserted.
- Quiet weeks reported as quiet; no manufactured drama.
- No trade recommendations. One-line footer: "Informational recap, not investment
  advice."
- Independent runs — recompute the window each time.
- Append a token-usage estimate to the chat message, per the user's standing preference.
