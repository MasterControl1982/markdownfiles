---
name: roi-analyzer
description: "Estimate and model Return on Investment (ROI) for business initiatives, technology projects, process improvements, or any capital investment. Use this skill whenever the user mentions ROI, return on investment, cost-benefit analysis, business case, investment justification, payback period, NPV, break-even analysis, or wants to evaluate whether an initiative is worth pursuing financially. Also trigger when the user says things like 'is this worth it', 'what's the financial impact', 'build a business case', 'justify this spend', 'estimate savings', or 'model the costs and benefits'. The skill produces a professional, editable Excel financial model with all assumptions exposed as blue-font inputs. Even if the user is vague about numbers, use this skill — it will guide the conversation to gather what's needed and make reasonable assumptions for the rest."
---

# ROI Analyzer Skill

## Purpose
Guide the user through a structured ROI analysis conversation, then produce a professional Excel financial model. The model captures both the benefit side (revenue generation, cost avoidance, cost savings, speed-of-delivery gains, accuracy improvements) and the cost side (development, ongoing, implementation, acquisition, transition), discounted at a default 5% rate.

## Workflow

### Phase 1 — Gather Context (Conversational)

Ask the user the following questions. You can combine related questions to keep the conversation flowing, but make sure you cover all areas before building the model. If the user gives partial info, make reasonable assumptions and state them clearly.

#### Company Profile
- **Company type**: Industry / sector (e.g., SaaS, manufacturing, healthcare, financial services)
- **Company size**: Annual revenue range or general scale (startup, mid-market, enterprise)
- **Primary clients**: B2B, B2C, government, internal
- **Number of employees**: Approximate headcount or range

#### Initiative Description
- **What is the initiative?** Brief description of the project, tool, process change, or investment
- **What problem does it solve?** Current pain point or opportunity
- **Timeline**: Expected duration from start to full value realization (months)
- **Who is affected?** Teams, departments, number of people impacted

#### Benefit Drivers (probe each — estimate if the user can't quantify)
- **Revenue generation**: Will this create new revenue streams or increase existing ones? By how much?
- **Cost savings**: Will this reduce direct costs (headcount, licenses, materials)? Estimate annual savings.
- **Cost avoidance**: Will this prevent future costs that would otherwise occur (hiring, penalties, infrastructure)?
- **Speed of delivery**: Will this accelerate time-to-market, reduce cycle times, or improve throughput? Translate to dollar value.
- **Accuracy / quality**: Will this reduce errors, rework, compliance risk, or customer churn? Translate to dollar value.

#### Cost Drivers (probe each)
- **Development cost** (one-time): Internal labor, external contractors, design, testing
- **Acquisition cost** (one-time): Software licenses, hardware, IP purchase
- **Implementation cost** (one-time): Integration, data migration, training, change management
- **Transition cost** (one-time): Parallel running, temporary productivity loss, decommissioning old systems
- **Ongoing cost** (annual): Maintenance, subscriptions, support staff, hosting, incremental licenses

### Phase 2 — State Assumptions

Before building the model, summarize all assumptions in plain language. For any value the user could not provide, state your assumption and the reasoning. Common assumptions to make:

- **Fully-loaded employee cost**: If unknown, assume based on company type and region:
  - US tech: ~$150K–$180K/year fully loaded
  - US non-tech professional: ~$80K–$120K/year
  - Adjust for other regions
- **Productivity gain translation**: If "saves 5 hours/week per person," convert to annual dollar value using hourly rate
- **Revenue ramp**: New revenue typically ramps — use 25% / 50% / 75% / 100% over 4 quarters unless told otherwise
- **Cost avoidance**: If avoiding a future hire, use fully-loaded cost of that role
- **Discount rate**: Default 5% unless user specifies otherwise
- **Analysis horizon**: Default 3 years unless user specifies otherwise
- **Tax rate**: Ignore taxes unless user requests after-tax analysis
- **Inflation on ongoing costs**: Default 3% annual escalation on ongoing costs

### Phase 3 — Build the Excel Model

Use the script at `scripts/generate_roi_model.py` to produce the Excel workbook. Pass all gathered parameters as a JSON config.

Run:
```bash
python scripts/generate_roi_model.py config.json output.xlsx
```

Then recalculate formulas:
```bash
python /mnt/skills/public/xlsx/scripts/recalc.py output.xlsx
```

#### Excel Model Structure

The workbook has three sheets:

**Sheet 1: Assumptions & Inputs**
- All editable inputs in blue font with yellow background
- Company profile summary at top
- Initiative description
- Benefit assumptions (annual values at full run-rate)
- Cost assumptions (one-time and ongoing)
- Model parameters (discount rate, analysis horizon, cost escalation rate)

**Sheet 2: ROI Model**
- Year 0 through Year N columns
- Benefits section: each benefit driver as a row, with ramp-up in Year 1
- Costs section: one-time costs in Year 0, ongoing costs in Years 1–N with escalation
- Subtotals for Total Benefits and Total Costs
- Net Benefit = Total Benefits − Total Costs
- Cumulative Net Benefit
- Discounted cash flows at the specified rate
- NPV (Net Present Value)
- Payback period (year in which cumulative net benefit turns positive)
- ROI % = (Total Discounted Benefits − Total Discounted Costs) / Total Discounted Costs

**Sheet 3: Summary Dashboard**
- Key metrics: NPV, ROI %, Payback Period, Total Investment, Total Benefits
- Sensitivity notes

#### Excel Formatting Rules
- Follow the xlsx skill color coding: blue text for inputs, black for formulas, green for cross-sheet links
- Yellow background on key assumption cells
- Currency format: $#,##0 with negative in parentheses
- Percentages: 0.0%
- All formulas reference assumption cells — no hardcoded numbers in the model sheet
- Column widths set for readability
- Headers bold with bottom border
- Freeze panes on the model sheet so row headers and year columns stay visible

### Phase 4 — Present Results

After generating the Excel file:
1. State the headline ROI metrics conversationally (NPV, ROI %, payback period)
2. Note which assumptions have the biggest impact on the result
3. Suggest what the user might want to adjust in the model
4. Provide the Excel file for download

## Key Principles
- **Always produce the Excel model** — that's the primary deliverable
- **Be transparent about assumptions** — clearly label what's estimated vs. user-provided
- **Make everything editable** — the user should be able to change any input and see the model update
- **Use Excel formulas, not hardcoded values** — the model must be a living tool
- **Discount rate defaults to 5%** but is an editable input
- **When in doubt, be conservative** — slightly underestimate benefits, slightly overestimate costs
