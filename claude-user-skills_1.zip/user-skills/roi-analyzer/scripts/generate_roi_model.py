#!/usr/bin/env python3
"""Generate a professional ROI analysis Excel workbook from a JSON config."""
import json, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Style constants
BLUE = Font(name='Arial', color='0000FF', size=11)
BLUE_B = Font(name='Arial', color='0000FF', size=11, bold=True)
BLK = Font(name='Arial', color='000000', size=11)
BLK_B = Font(name='Arial', color='000000', size=11, bold=True)
GRN = Font(name='Arial', color='008000', size=11)
GRN_B = Font(name='Arial', color='008000', size=11, bold=True)
HDR = Font(name='Arial', color='FFFFFF', size=11, bold=True)
TITLE = Font(name='Arial', color='000000', size=14, bold=True)
SEC = Font(name='Arial', color='000000', size=12, bold=True)
NOTE = Font(name='Arial', italic=True, color='666666', size=10)

YEL = PatternFill('solid', fgColor='FFFF00')
HDR_FILL = PatternFill('solid', fgColor='4472C4')
LT_BLU = PatternFill('solid', fgColor='D6E4F0')
LT_GRY = PatternFill('solid', fgColor='F2F2F2')
LT_GRN = PatternFill('solid', fgColor='E2EFDA')
LT_RED = PatternFill('solid', fgColor='FCE4EC')
SUMM_FILL = PatternFill('solid', fgColor='D9E2F3')

CTR = Alignment(horizontal='center', vertical='center')
LFT = Alignment(horizontal='left', vertical='center')
RT = Alignment(horizontal='right', vertical='center')
WRP = Alignment(horizontal='left', vertical='top', wrap_text=True)

THIN_B = Border(bottom=Side(style='thin', color='000000'))
MED_B = Border(bottom=Side(style='medium', color='000000'))

CUR = '$#,##0;($#,##0);"-"'
PCT = '0.0%'
NUM = '#,##0'
YRS = '0.0'


def sc(ws, r, c, val, font=BLK, fill=None, fmt=None, align=LFT, brd=None):
    cell = ws.cell(row=r, column=c, value=val)
    cell.font = font
    if fill: cell.fill = fill
    if fmt: cell.number_format = fmt
    cell.alignment = align
    if brd: cell.border = brd
    return cell


def build_assumptions(wb, cfg):
    ws = wb.active
    ws.title = "Assumptions & Inputs"
    ws.sheet_properties.tabColor = "4472C4"
    ws.column_dimensions['A'].width = 4
    ws.column_dimensions['B'].width = 38
    ws.column_dimensions['C'].width = 22
    ws.column_dimensions['D'].width = 48

    r = 2
    sc(ws, r, 2, "ROI Analysis — Assumptions & Inputs", TITLE); r += 1
    sc(ws, r, 2, "Blue cells are editable inputs. Change them to run scenarios.", NOTE); r += 2

    # Company Profile
    sc(ws, r, 2, "Company Profile", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); sc(ws, r, 4, "", brd=MED_B); r += 1
    sc(ws, r, 2, "Industry / Sector"); sc(ws, r, 3, cfg.get('company_type', 'Technology'), BLUE, YEL); r += 1
    sc(ws, r, 2, "Company Size"); sc(ws, r, 3, cfg.get('company_size', 'Mid-Market'), BLUE, YEL); r += 1
    sc(ws, r, 2, "Primary Clients"); sc(ws, r, 3, cfg.get('clients', 'B2B'), BLUE, YEL); r += 1
    sc(ws, r, 2, "Number of Employees"); sc(ws, r, 3, cfg.get('num_employees', 500), BLUE, YEL, NUM); emp_r = r; r += 2

    # Initiative
    sc(ws, r, 2, "Initiative Description", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); sc(ws, r, 4, "", brd=MED_B); r += 1
    sc(ws, r, 2, "Initiative Name"); sc(ws, r, 3, cfg.get('initiative_name', 'New Initiative'), BLUE, YEL); r += 1
    sc(ws, r, 2, "Description"); sc(ws, r, 3, cfg.get('initiative_description', ''), BLUE, YEL, align=WRP)
    ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=4); ws.row_dimensions[r].height = 45; r += 1
    sc(ws, r, 2, "Timeline (months to full value)"); sc(ws, r, 3, cfg.get('timeline_months', 12), BLUE, YEL, NUM); r += 1
    sc(ws, r, 2, "People Impacted"); sc(ws, r, 3, cfg.get('people_impacted', 50), BLUE, YEL, NUM); r += 2

    # Model Parameters
    sc(ws, r, 2, "Model Parameters", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); sc(ws, r, 4, "", brd=MED_B); r += 1
    sc(ws, r, 2, "Analysis Horizon (years)"); sc(ws, r, 3, cfg.get('horizon_years', 3), BLUE, YEL, NUM); hz_r = r; r += 1
    sc(ws, r, 2, "Discount Rate"); sc(ws, r, 3, cfg.get('discount_rate', 0.05), BLUE, YEL, PCT); dr_r = r; r += 1
    sc(ws, r, 2, "Ongoing Cost Escalation Rate"); sc(ws, r, 3, cfg.get('escalation_rate', 0.03), BLUE, YEL, PCT); esc_r = r; r += 1
    sc(ws, r, 2, "Benefit Ramp — Year 1 Factor"); sc(ws, r, 3, cfg.get('ramp_year1', 0.50), BLUE, YEL, PCT)
    sc(ws, r, 4, "Benefits realize at this fraction in Year 1, then 100% after", NOTE); ramp_r = r; r += 1
    sc(ws, r, 2, "Fully-Loaded Employee Cost ($/yr)"); sc(ws, r, 3, cfg.get('loaded_employee_cost', 150000), BLUE, YEL, CUR); ec_r = r; r += 2

    # Benefits
    sc(ws, r, 2, "Annual Benefit Assumptions (at full run-rate)", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); sc(ws, r, 4, "", brd=MED_B); r += 1
    benefits = cfg.get('benefits', {})
    b_keys = [
        ('revenue_generation', 'Revenue Generation (new/incremental)'),
        ('cost_savings', 'Direct Cost Savings'),
        ('cost_avoidance', 'Cost Avoidance'),
        ('speed_of_delivery', 'Speed-of-Delivery Gains ($)'),
        ('accuracy_quality', 'Accuracy / Quality Improvements ($)'),
    ]
    b_rows = {}
    for k, lbl in b_keys:
        sc(ws, r, 2, lbl); sc(ws, r, 3, benefits.get(k, 0), BLUE, YEL, CUR)
        sc(ws, r, 4, benefits.get(f'{k}_note', ''), NOTE); b_rows[k] = r; r += 1
    r += 1

    # Costs
    sc(ws, r, 2, "Cost Assumptions", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); sc(ws, r, 4, "", brd=MED_B); r += 1
    sc(ws, r, 2, "One-Time Costs", BLK_B, LT_GRY); r += 1
    costs = cfg.get('costs', {})
    ot_keys = [
        ('development_cost', 'Development Cost'),
        ('acquisition_cost', 'Acquisition Cost (licenses, hardware, IP)'),
        ('implementation_cost', 'Implementation Cost (integration, training)'),
        ('transition_cost', 'Transition Cost (parallel run, decommission)'),
    ]
    ot_rows = {}
    for k, lbl in ot_keys:
        sc(ws, r, 2, lbl); sc(ws, r, 3, costs.get(k, 0), BLUE, YEL, CUR)
        sc(ws, r, 4, costs.get(f'{k}_note', ''), NOTE); ot_rows[k] = r; r += 1
    r += 1

    sc(ws, r, 2, "Ongoing Annual Costs", BLK_B, LT_GRY); r += 1
    og_keys = [
        ('ongoing_maintenance', 'Maintenance & Support'),
        ('ongoing_subscriptions', 'Software Subscriptions / Hosting'),
        ('ongoing_staffing', 'Incremental Staffing'),
        ('ongoing_other', 'Other Ongoing Costs'),
    ]
    og_rows = {}
    for k, lbl in og_keys:
        sc(ws, r, 2, lbl); sc(ws, r, 3, costs.get(k, 0), BLUE, YEL, CUR)
        sc(ws, r, 4, costs.get(f'{k}_note', ''), NOTE); og_rows[k] = r; r += 1

    return dict(hz_r=hz_r, dr_r=dr_r, esc_r=esc_r, ramp_r=ramp_r, ec_r=ec_r,
                b_rows=b_rows, ot_rows=ot_rows, og_rows=og_rows, emp_r=emp_r)


def build_model(wb, cfg, refs):
    ws = wb.create_sheet("ROI Model")
    ws.sheet_properties.tabColor = "548235"
    H = cfg.get('horizon_years', 3)
    A = "'Assumptions & Inputs'"

    ws.column_dimensions['A'].width = 4
    ws.column_dimensions['B'].width = 38
    for yi in range(H + 1):
        ws.column_dimensions[get_column_letter(3 + yi)].width = 18

    r = 2; sc(ws, r, 2, "ROI Financial Model", TITLE); r += 2

    # Year headers
    sc(ws, r, 2, "", font=HDR, fill=HDR_FILL)
    for yi in range(H + 1):
        sc(ws, r, 3 + yi, f"Year {yi}", HDR, HDR_FILL, align=CTR)
    r += 1

    # BENEFITS
    sc(ws, r, 2, "BENEFITS", SEC, LT_GRN, brd=MED_B)
    for yi in range(H + 1): sc(ws, r, 3 + yi, "", fill=LT_GRN, brd=MED_B)
    r += 1

    b_start = r
    for k, lbl in [('revenue_generation','Revenue Generation'),('cost_savings','Direct Cost Savings'),
                    ('cost_avoidance','Cost Avoidance'),('speed_of_delivery','Speed-of-Delivery Gains'),
                    ('accuracy_quality','Accuracy / Quality Improvements')]:
        sc(ws, r, 2, lbl, GRN)
        br = refs['b_rows'][k]
        for yi in range(H + 1):
            c = 3 + yi
            if yi == 0:
                sc(ws, r, c, 0, BLK, fmt=CUR, align=RT)
            elif yi == 1:
                sc(ws, r, c, f"={A}!C{br}*{A}!C{refs['ramp_r']}", GRN, fmt=CUR, align=RT)
            else:
                sc(ws, r, c, f"={A}!C{br}", GRN, fmt=CUR, align=RT)
        r += 1
    b_end = r - 1

    # Total Benefits
    sc(ws, r, 2, "Total Annual Benefits", BLK_B, brd=MED_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"=SUM({cl}{b_start}:{cl}{b_end})", BLK_B, fmt=CUR, align=RT, brd=MED_B)
    tb_r = r; r += 2

    # COSTS
    sc(ws, r, 2, "COSTS", SEC, LT_RED, brd=MED_B)
    for yi in range(H + 1): sc(ws, r, 3 + yi, "", fill=LT_RED, brd=MED_B)
    r += 1

    sc(ws, r, 2, "One-Time Costs", BLK_B, LT_GRY)
    for yi in range(H + 1): sc(ws, r, 3 + yi, "", fill=LT_GRY)
    r += 1

    ot_start = r
    for k, lbl in [('development_cost','Development'),('acquisition_cost','Acquisition'),
                    ('implementation_cost','Implementation'),('transition_cost','Transition')]:
        sc(ws, r, 2, lbl)
        otr = refs['ot_rows'][k]
        for yi in range(H + 1):
            c = 3 + yi
            if yi == 0:
                sc(ws, r, c, f"={A}!C{otr}", GRN, fmt=CUR, align=RT)
            else:
                sc(ws, r, c, 0, BLK, fmt=CUR, align=RT)
        r += 1
    ot_end = r - 1

    sc(ws, r, 2, "Subtotal One-Time", BLK_B, brd=THIN_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"=SUM({cl}{ot_start}:{cl}{ot_end})", BLK_B, fmt=CUR, align=RT, brd=THIN_B)
    sot_r = r; r += 2

    sc(ws, r, 2, "Ongoing Annual Costs", BLK_B, LT_GRY)
    for yi in range(H + 1): sc(ws, r, 3 + yi, "", fill=LT_GRY)
    r += 1

    og_start = r
    for k, lbl in [('ongoing_maintenance','Maintenance & Support'),('ongoing_subscriptions','Subscriptions / Hosting'),
                    ('ongoing_staffing','Incremental Staffing'),('ongoing_other','Other Ongoing')]:
        sc(ws, r, 2, lbl)
        ogr = refs['og_rows'][k]
        for yi in range(H + 1):
            c = 3 + yi
            if yi == 0:
                sc(ws, r, c, 0, BLK, fmt=CUR, align=RT)
            elif yi == 1:
                sc(ws, r, c, f"={A}!C{ogr}", GRN, fmt=CUR, align=RT)
            else:
                pc = get_column_letter(c - 1)
                sc(ws, r, c, f"={pc}{r}*(1+{A}!C{refs['esc_r']})", BLK, fmt=CUR, align=RT)
        r += 1
    og_end = r - 1

    sc(ws, r, 2, "Subtotal Ongoing", BLK_B, brd=THIN_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"=SUM({cl}{og_start}:{cl}{og_end})", BLK_B, fmt=CUR, align=RT, brd=THIN_B)
    sog_r = r; r += 1

    sc(ws, r, 2, "Total Annual Costs", BLK_B, brd=MED_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"={cl}{sot_r}+{cl}{sog_r}", BLK_B, fmt=CUR, align=RT, brd=MED_B)
    tc_r = r; r += 2

    # NET BENEFIT
    sc(ws, r, 2, "NET BENEFIT", SEC, LT_BLU, brd=MED_B)
    for yi in range(H + 1): sc(ws, r, 3 + yi, "", fill=LT_BLU, brd=MED_B)
    r += 1

    sc(ws, r, 2, "Net Annual Benefit", BLK_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"={cl}{tb_r}-{cl}{tc_r}", BLK_B, fmt=CUR, align=RT)
    nb_r = r; r += 1

    sc(ws, r, 2, "Cumulative Net Benefit", BLK_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        if yi == 0:
            sc(ws, r, c, f"={cl}{nb_r}", BLK_B, fmt=CUR, align=RT)
        else:
            pc = get_column_letter(c - 1)
            sc(ws, r, c, f"={pc}{r}+{cl}{nb_r}", BLK_B, fmt=CUR, align=RT)
    cum_r = r; r += 2

    # Discounted Cash Flow
    sc(ws, r, 2, "DISCOUNTED CASH FLOW", SEC, LT_BLU, brd=MED_B)
    for yi in range(H + 1): sc(ws, r, 3 + yi, "", fill=LT_BLU, brd=MED_B)
    r += 1

    sc(ws, r, 2, "Discount Factor")
    for yi in range(H + 1):
        c = 3 + yi
        sc(ws, r, c, f"=1/(1+{A}!C{refs['dr_r']})^{yi}", BLK, fmt='0.0000', align=RT)
    df_r = r; r += 1

    sc(ws, r, 2, "Discounted Net Benefit", BLK_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"={cl}{nb_r}*{cl}{df_r}", BLK_B, fmt=CUR, align=RT)
    dnb_r = r; r += 1

    sc(ws, r, 2, "Discounted Benefits", BLK)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"={cl}{tb_r}*{cl}{df_r}", BLK, fmt=CUR, align=RT)
    db_r = r; r += 1

    sc(ws, r, 2, "Discounted Costs", BLK)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        sc(ws, r, c, f"={cl}{tc_r}*{cl}{df_r}", BLK, fmt=CUR, align=RT)
    dc_r = r; r += 1

    sc(ws, r, 2, "Cumulative Discounted Net Benefit", BLK_B, brd=MED_B)
    for yi in range(H + 1):
        c = 3 + yi; cl = get_column_letter(c)
        if yi == 0:
            sc(ws, r, c, f"={cl}{dnb_r}", BLK_B, fmt=CUR, align=RT, brd=MED_B)
        else:
            pc = get_column_letter(c - 1)
            sc(ws, r, c, f"={pc}{r}+{cl}{dnb_r}", BLK_B, fmt=CUR, align=RT, brd=MED_B)
    cdnb_r = r; r += 2

    # KEY METRICS
    sc(ws, r, 2, "KEY METRICS", SEC, SUMM_FILL, brd=MED_B)
    sc(ws, r, 3, "", fill=SUMM_FILL, brd=MED_B); r += 1

    last_col = get_column_letter(3 + H)
    sc(ws, r, 2, "Net Present Value (NPV)", BLK_B)
    sc(ws, r, 3, f"=SUM(C{dnb_r}:{last_col}{dnb_r})", BLK_B, fmt=CUR, align=RT)
    npv_r = r; r += 1

    sc(ws, r, 2, "Total Discounted Benefits", BLK)
    sc(ws, r, 3, f"=SUM(C{db_r}:{last_col}{db_r})", BLK, fmt=CUR, align=RT)
    tdb_r = r; r += 1

    sc(ws, r, 2, "Total Discounted Costs", BLK)
    sc(ws, r, 3, f"=SUM(C{dc_r}:{last_col}{dc_r})", BLK, fmt=CUR, align=RT)
    tdc_r = r; r += 1

    sc(ws, r, 2, "ROI %", BLK_B)
    sc(ws, r, 3, f"=IF(C{tdc_r}=0,0,(C{tdb_r}-C{tdc_r})/C{tdc_r})", BLK_B, fmt=PCT, align=RT)
    roi_r = r; r += 1

    sc(ws, r, 2, "Total Investment (undiscounted)", BLK)
    sc(ws, r, 3, f"=SUM(C{tc_r}:{last_col}{tc_r})", BLK, fmt=CUR, align=RT)
    r += 1

    sc(ws, r, 2, "Payback Period (years)", BLK_B)
    # Approximate payback: find first year where cumulative >= 0
    # Use a nested IF to scan each year
    parts = []
    for yi in range(H + 1):
        cl = get_column_letter(3 + yi)
        parts.append(f"IF({cl}{cum_r}>=0,{yi}")
    formula = "=" + ",".join(parts) + ',"Beyond horizon"' + ")" * (H + 1)
    sc(ws, r, 3, formula, BLK_B, fmt=YRS, align=RT)
    pb_r = r

    # Freeze panes
    ws.freeze_panes = 'C6'

    return dict(npv_r=npv_r, roi_r=roi_r, pb_r=pb_r, tdb_r=tdb_r, tdc_r=tdc_r,
                tb_r=tb_r, tc_r=tc_r, nb_r=nb_r, cum_r=cum_r)


def build_summary(wb, cfg, model_refs):
    ws = wb.create_sheet("Summary Dashboard")
    ws.sheet_properties.tabColor = "FFC000"

    ws.column_dimensions['A'].width = 4
    ws.column_dimensions['B'].width = 32
    ws.column_dimensions['C'].width = 24
    ws.column_dimensions['D'].width = 48

    r = 2; sc(ws, r, 2, "ROI Summary Dashboard", TITLE); r += 2

    sc(ws, r, 2, "Key Financial Metrics", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); r += 1

    M = "'ROI Model'"
    metrics = [
        ("Net Present Value (NPV)", f"={M}!C{model_refs['npv_r']}", CUR),
        ("ROI %", f"={M}!C{model_refs['roi_r']}", PCT),
        ("Payback Period (years)", f"={M}!C{model_refs['pb_r']}", YRS),
        ("Total Discounted Benefits", f"={M}!C{model_refs['tdb_r']}", CUR),
        ("Total Discounted Costs", f"={M}!C{model_refs['tdc_r']}", CUR),
    ]
    for lbl, formula, fmt in metrics:
        sc(ws, r, 2, lbl, BLK_B, SUMM_FILL)
        sc(ws, r, 3, formula, GRN_B, SUMM_FILL, fmt, RT)
        r += 1

    r += 1
    sc(ws, r, 2, "Interpretation Guide", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); sc(ws, r, 4, "", brd=MED_B); r += 1
    notes = [
        ("NPV > 0", "The initiative creates value above the required return rate"),
        ("ROI % > 0%", "Benefits exceed costs on a discounted basis"),
        ("Payback < Horizon", "Investment recovers before the analysis period ends"),
        ("Discount Rate = 5%", "Reflects opportunity cost of capital; editable on Assumptions sheet"),
        ("Year 1 Ramp", "Benefits are reduced in Year 1 to account for adoption curve"),
    ]
    for lbl, desc in notes:
        sc(ws, r, 2, lbl, BLK_B)
        sc(ws, r, 3, desc, NOTE, align=WRP)
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=4)
        r += 1

    r += 1
    sc(ws, r, 2, "Next Steps", SEC, brd=MED_B); sc(ws, r, 3, "", brd=MED_B); r += 1
    steps = [
        "1. Review and adjust blue input cells on the Assumptions sheet",
        "2. Check the ROI Model sheet to see updated year-by-year projections",
        "3. Run sensitivity analysis by changing discount rate, ramp, and cost escalation",
        "4. Present to stakeholders using this Summary Dashboard",
    ]
    for s in steps:
        sc(ws, r, 2, s, BLK); r += 1


def main():
    if len(sys.argv) < 3:
        print("Usage: python generate_roi_model.py config.json output.xlsx")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        cfg = json.load(f)

    wb = Workbook()
    refs = build_assumptions(wb, cfg)
    model_refs = build_model(wb, cfg, refs)
    build_summary(wb, cfg, model_refs)

    out = sys.argv[2]
    wb.save(out)
    print(f"Saved to {out}")


if __name__ == '__main__':
    main()
