---
name: investment-thesis
description: >
  Generate deep, multilayer investment theories for any macro event, geopolitical
  conflict, commodity shock, policy change, or market theme. Use this skill whenever
  the user wants to explore investment ideas, trading theories, or market impact
  analysis around a specific event or topic — even if they phrase it casually, like
  "give me investment ideas on X", "what are the plays around Y", "how do I trade Z",
  "what are the second-order effects of X on markets", or "build me an investment thesis
  on X". Always use this skill for any investment theory or macro trade idea request,
  regardless of whether the user says "thesis", "theory", "idea", or "play". Produces
  interactive visualizations with causal chain diagrams, conviction ratings, risk
  profiles, and detailed written analysis across multiple asset classes.
---

# Investment Thesis Skill

Generates multilayer, cascading investment theories for any macro event or theme.
The output goes well beyond first-order plays (e.g. "buy oil when there's an oil shock")
and maps the full causal chain: second- and third-order effects across commodities,
equities, currencies, bonds, and niche subsectors.

---

## Step 1 — Elicit the topic

**Always ask the user for the topic first.** Do not assume or proceed without it.

Ask one focused question:

> "What's the event, theme, or macro topic you want investment theories on? For example: a geopolitical conflict, a commodity shortage, a policy shift, a technology disruption, an election outcome — anything."

Wait for their answer before proceeding.

---

## Step 2 — Research the topic

Once the user supplies the topic, do **aggressive web research** before generating any theories. The quality of the theories depends entirely on how well you understand the current state of the topic.

Search for:
- Current status / most recent developments (use today's date in queries)
- Market data already moved (what's priced in vs. what isn't)
- Supply chain dependencies and chokepoints
- Second-order commodity, currency, and sector exposures
- Analyst commentary, bank research notes, expert quotes
- Any "hidden" linkages — industries that seem unrelated but are actually exposed

Run **at least 3–4 searches**, including at least one specifically targeting second-order or downstream effects. Examples:
- `"[topic] market impact second order effects [year]"`
- `"[topic] [specific commodity or sector] supply chain [year]"`
- `"[topic] investment thesis [year]"`
- `"[topic] [currency / EM / bonds] [year]"`

Synthesize findings before generating theories. The goal is to surface non-obvious connections.

---

## Step 3 — Generate 5 multilayer investment theories

Each theory must:

1. **Have a clear name** — descriptive, not generic ("The Helium → AI Infrastructure Squeeze", not "Long commodities")
2. **Show a causal chain with at least 4 layers** — Layer 1 is the event; Layers 2–4 are the cascading effects
3. **Identify specific instruments** — tickers, ETFs, futures contracts, or currency pairs
4. **Distinguish 1st, 2nd, and 3rd order effects** — tag each theory accordingly
5. **Include a risk/caveat section** — especially the "theory-killer" scenario (e.g. a ceasefire, a policy reversal)
6. **Rate conviction (1–10) and time horizon** — be honest about uncertainty

Aim for **variety across tiers**:
- At least 1 obvious/liquid play (e.g. a large-cap stock or commodity ETF)
- At least 1 counterintuitive or non-obvious play
- At least 1 short or hedge idea
- At least 1 emerging-market or currency angle if relevant
- At least 1 niche/second-order play most people haven't thought of

---

## Step 4 — Build the interactive visualization

Use the `visualize:show_widget` tool to render the theories as an **interactive dashboard**.

The visualization must include:

### Required elements:
- **Tab navigation** — at minimum: one tab per theory + a summary matrix tab
- **Causal chain nodes** for each theory — show 4 boxes connected by arrows, one per layer
- **Meta stats per theory**: conviction score (bar), risk score (bar), time horizon
- **Instrument tags** — color-coded pills for Long / Short / Hedge instruments
- **Caveat/risk box** at the bottom of each theory card
- **Summary matrix** — all 5 theories on one view with conviction bars, color-coded by order (2nd vs 3rd order), and time horizon

### Design rules (must follow):
- Use CSS variables only — no hardcoded colors
- Tabs switch content via JS, never `display:none` during streaming
- All text on colored backgrounds must use the same color ramp (800/900 for text on 50/100 fills)
- No gradients, no shadows, no fixed positioning
- Works in dark mode

### Context stats bar at the top:
Pull 4 current data points from your research (e.g. oil price, a commodity price, a yield, a percentage move) and show them as metric cards above the tabs. These ground the theories in live numbers.

---

## Step 5 — Write the analysis prose

After the widget, write **one substantive paragraph per theory** in the conversation (outside the widget). Each paragraph should:

- Explain the mechanism that most investors are missing
- Cite at least one specific data point or analyst quote from your research
- Name the specific catalyst or timing trigger
- Contrast the near-term trade vs. the structural multi-month thesis
- Note the single biggest risk to that theory

Keep the prose tight — these should read like a smart analyst note, not a blog post.

---

## Output format summary

```
[One-sentence framing of the topic and why it matters today]

[Widget: interactive 5-theory dashboard]

[Theory 1 prose paragraph — mechanism + data + risk]
[Theory 2 prose paragraph]
[Theory 3 prose paragraph]
[Theory 4 prose paragraph]
[Theory 5 prose paragraph]

[Optional: closing meta-observation about the shared risk across all theories]
```

---

## Quality criteria

A strong output:
- Has at least 2 theories most people wouldn't immediately think of
- Ties at least one theory to a non-energy, non-commodity market (e.g. currency, credit, tech input, agriculture, shipping)
- Names specific, investable tickers — not vague sector ETFs alone
- Has a clear "theory-killer" risk for each play
- Shows the full causal chain, not just "X causes Y"
- Cites real data from the research, not hallucinated numbers

A weak output:
- Lists only the obvious plays (buy oil, buy defense)
- Has no causal chain logic — just "X is bad for Y"
- Uses vague instrument descriptions ("energy stocks")
- Skips the counterintuitive or short idea
- Has no conviction differentiation — everything rated the same

---

## Notes on specific topic types

**Geopolitical conflicts**: Focus on supply chain chokepoints, insurance/shipping disruptions, fertilizer/food second-order effects, EM currency stress, and defense procurement cycles. Don't just do oil.

**Central bank / monetary policy**: Focus on duration, credit spreads, EM carry trade unwinds, USD impact on commodity importers, and real estate financing stress.

**Technology disruptions**: Focus on input material supply chains (rare earths, specialty gases, chemicals), picks-and-shovels plays (equipment makers, cooling systems), and the demand-destruction side for legacy industries.

**Commodity shocks**: Go deep on downstream users, substitute commodities, refining margin dynamics, fertilizer/food linkages, and geographic supply diversification plays.

**Elections / policy shifts**: Focus on regulatory winners/losers, government spending redirects, tariff supply chain rerouting, and currency impacts on trade-exposed sectors.
