---
name: frd-generator
description: "Use this skill whenever the user wants to create a Functional Requirements Document (FRD), technical requirements doc, solution research document, or architecture proposal to solve a problem. Triggers include: any mention of 'FRD', 'functional requirements', 'requirements document', 'solution research', 'architecture document', 'technical proposal', or when a user describes a problem and asks Claude to research solutions, compare open source options, or design a modular system. Also trigger when the user says things like 'figure out how to solve X', 'what are my options for building Y', 'write up a plan for Z', 'research approaches for this problem', or 'design an architecture for this'. If the user has a technical problem and wants a structured document that researches solutions and proposes an architecture, use this skill — even if they don't explicitly say 'FRD'."
---

# Functional Requirements Document Generator

## Purpose

This skill produces a deep-research Functional Requirements Document in Markdown. The FRD takes a problem statement, researches the landscape of solutions (with emphasis on open source), compares approaches in a structured matrix, and proposes a modular architecture designed for future change.

The goal is not just to document requirements — it's to do the homework. The user walks away with a document they can hand to a team or use as a decision-making artifact, confident that the solution space has been thoroughly explored.

## Workflow

Follow these phases in order. Each phase builds on the last.

### Phase 1: Understand the Problem

Before writing anything, make sure you deeply understand what the user is trying to solve.

1. Read the user's problem description carefully. Identify:
   - The core problem (what's broken, missing, or needed)
   - Who's affected (users, teams, systems)
   - Constraints (budget, timeline, existing tech stack, compliance, scale)
   - What "success" looks like

2. If the problem is ambiguous or underspecified, ask targeted clarifying questions. Focus on constraints and scope — those shape which solutions are viable. Don't ask more than 3 questions at a time.

3. Summarize your understanding back to the user in 2-3 sentences before proceeding. This catches misunderstandings early.

### Phase 2: Research the Solution Landscape

This is the most important phase. Use web search extensively to build a thorough picture of how this problem is solved today.

1. **Search broadly first.** Start with 2-3 broad queries about the problem domain to understand the categories of solutions (e.g., "open source workflow orchestration tools", "approaches to real-time data sync").

2. **Go deep on each category.** For each major approach or tool discovered, search for:
   - Official project pages and documentation
   - GitHub repos — check stars, recent commit activity, license
   - Community adoption signals (blog posts, conference talks, Stack Overflow activity)
   - Known limitations and failure modes

3. **Find at least 3-5 viable open source solutions.** For each one, gather:
   - Name, URL, license type
   - What it does and how it approaches the problem
   - Maturity (age, release cadence, contributor count)
   - Community size and activity
   - Integration story (APIs, plugins, SDKs)
   - Known weaknesses or gaps

4. **Identify non-open-source approaches too** (managed services, SaaS, build-from-scratch) so the comparison is honest. The user asked for open source emphasis, but they need to know the full picture to make a good decision.

5. **Look for cautionary tales.** Search for failure cases, migration stories, and "why we switched from X to Y" posts. These are gold for the recommendations section.

### Phase 3: Design the Modular Architecture

With the research complete, design an architecture that:

1. **Separates concerns into distinct modules.** Each module should have a single responsibility and a clear interface. Think about:
   - What are the natural boundaries in this system?
   - Which parts are most likely to change?
   - Where do external dependencies live?

2. **Uses the adapter/plugin pattern for swappable components.** The whole point of modularity here is future-proofing. If the user picks Tool A today and wants to switch to Tool B next year, the architecture should make that a module swap, not a rewrite. Define clear interfaces/contracts between modules.

3. **Identifies the stable core vs. the volatile edges.** The center of the architecture should be business logic that rarely changes. The edges — integrations, UIs, data sources — are where change happens. Design accordingly.

4. **Considers these architectural qualities:**
   - Testability: Can each module be tested independently?
   - Deployability: Can modules be deployed or scaled independently if needed?
   - Observability: Where do logs, metrics, and health checks live?

### Phase 4: Write the FRD

Produce the document as a single Markdown file with the structure below. Write in clear, direct prose. Avoid filler. Every sentence should either inform a decision or clarify a requirement.

---

## FRD Document Structure

Use this exact structure for the output document:

```
# Functional Requirements Document: [Descriptive Title]

**Date:** [today's date]
**Status:** Draft
**Author:** Generated with AI assistance

---

## 1. Problem Statement & Goals

### 1.1 Problem Description
[2-3 paragraphs. What's the problem? Who does it affect? Why does it matter now?]

### 1.2 Goals
[Bulleted list of specific, measurable goals this solution must achieve]

### 1.3 Non-Goals
[Explicitly state what's out of scope — this prevents scope creep]

### 1.4 Constraints
[Technical, budgetary, timeline, regulatory, or organizational constraints]

---

## 2. Solution Landscape Research

### 2.1 Approach Categories
[Overview of the major categories of solutions discovered. Example: "Solutions fall into three categories: dedicated orchestration platforms, library-based approaches, and managed cloud services."]

### 2.2 Open Source Solutions

For each solution, include a subsection:

#### [Solution Name]
- **Repository:** [GitHub/GitLab URL]
- **License:** [e.g., MIT, Apache 2.0, AGPL]
- **Maturity:** [e.g., "v3.2, first release 2019, 450+ contributors"]
- **Community:** [stars, recent activity, ecosystem]
- **How it works:** [1-2 paragraphs on the approach]
- **Strengths:** [bulleted]
- **Weaknesses:** [bulleted]
- **Integration notes:** [APIs, SDKs, plugin ecosystem]

### 2.3 Alternative Approaches
[Managed services, SaaS, or build-from-scratch options worth noting]

### 2.4 Comparison Matrix

| Criteria | Solution A | Solution B | Solution C | ... |
|----------|-----------|-----------|-----------|-----|
| License | | | | |
| Maturity | | | | |
| Community Activity | | | | |
| Ease of Integration | | | | |
| Scalability | | | | |
| Learning Curve | | | | |
| Modularity / Plugin Support | | | | |
| Active Maintenance | | | | |
| [Domain-specific criteria] | | | | |

### 2.5 Recommendation
[Which solution(s) to pursue and why. Be specific about the reasoning. If it's "it depends," explain what it depends on.]

---

## 3. Modular Architecture

### 3.1 Architecture Overview
[High-level description of the proposed architecture in 2-3 paragraphs. Explain the philosophy: why these modules, why these boundaries.]

### 3.2 Architecture Diagram
[Mermaid diagram showing modules, their relationships, and data flow]

### 3.3 Module Definitions

For each module:

#### Module: [Name]
- **Responsibility:** [Single sentence]
- **Interface:** [What it exposes — APIs, events, contracts]
- **Dependencies:** [What it consumes]
- **Swappability:** [What can be swapped out and how — e.g., "Database adapter implements StorageInterface; swap Postgres for MySQL by implementing the same interface"]
- **Technology recommendation:** [Specific tool/library from the research]

### 3.4 Interface Contracts
[Define the key interfaces between modules. These are the stable contracts that allow modules to be swapped. Use pseudocode, API signatures, or event schemas as appropriate.]

### 3.5 Data Flow
[Describe how data moves through the system, module to module. A Mermaid sequence diagram works well here.]

---

## 4. Risks & Mitigations
[Table format: Risk | Likelihood | Impact | Mitigation]

---

## 5. Open Questions
[Decisions that still need to be made, areas needing further research, or stakeholder input required]
```

---

## Architecture Diagram Guidelines

Use Mermaid syntax for all diagrams. Include at minimum:

1. **A component/module diagram** showing the major modules and their relationships:
```mermaid
graph TB
    subgraph Core
        A[Business Logic]
    end
    subgraph Adapters
        B[Data Adapter]
        C[API Adapter]
    end
    A --> B
    A --> C
```

2. **A data flow / sequence diagram** if the system involves multi-step processing:
```mermaid
sequenceDiagram
    participant Client
    participant API
    participant Core
    participant Store
    Client->>API: Request
    API->>Core: Process
    Core->>Store: Persist
    Store-->>Core: Confirm
    Core-->>API: Result
    API-->>Client: Response
```

Adapt these to the actual system. Don't use generic placeholder names — use names that reflect the real modules.

---

## Quality Checklist

Before delivering the FRD, verify:

- [ ] Problem statement is specific enough that someone unfamiliar could understand it
- [ ] At least 3 open source solutions are researched with real GitHub/project links
- [ ] Comparison matrix uses criteria relevant to this specific problem
- [ ] Recommendation is justified with clear reasoning, not just "it's popular"
- [ ] Architecture diagram uses real module names, not generic placeholders
- [ ] Every module has a defined interface and swappability story
- [ ] Risks section includes at least one risk related to the recommended solution
- [ ] Open questions section is honest about what's still unknown

## Output

Save the final document as a `.md` file in the output directory. The filename should be descriptive: `frd-[problem-domain].md` (e.g., `frd-event-streaming-pipeline.md`).
