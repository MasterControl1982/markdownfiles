---
name: foodattractions
description: >
  Research and build a Google Maps location guide for the top 3 places across multiple
  attraction categories in any city or destination. Use this skill whenever the user asks
  for a map, location guide, or "top places" covering food, dining, nightlife, entertainment,
  or shopping in a specific city — even if they don't say "skill" or "map" explicitly.
  Trigger this skill for requests like "top places in X", "best spots in X", "make me a map
  of X", "where to go in X for food and nightlife", or any request combining 2+ categories
  (buffets, local food, bars, clubs, pool halls, shopping, markets, cafes, etc.) for a
  specific destination. Always use this skill when the user wants a researched, multi-category
  location guide with a map output.
---

# FoodAttractions Skill

Produce a fully researched, multi-category Google Maps guide for the top 3 places per
category in any destination. Rankings are based on cross-referencing TripAdvisor, Google
Reviews, travel blogs, and YouTube vlogs — not just the first Google result.

---

## Step 1 — Parse the Request

Extract:
- **Destination** (city/area)
- **Categories requested** — common ones include:
  - Buffets
  - Local / street food restaurants
  - Pool halls / billiards
  - Bars & nightclubs
  - Shopping (malls, markets, night markets)
  - Cafes / coffee shops
  - Seafood restaurants
  - Rooftop bars
  - Beach clubs

If categories are vague (e.g. "food and fun"), infer the most likely ones from context and proceed — don't ask for clarification unless the destination itself is unclear.

---

## Step 2 — Research Each Category

For each category, run **web searches** targeting multiple sources. Use the pattern:

```
best [category] [destination] [year] tripadvisor
best [category] [destination] google reviews
top [category] [destination] youtube
[destination] [category] blog recommendations 2024 2025
```

**Minimum sources to cross-reference per category:**
- TripAdvisor (rankings + traveler reviews)
- Google Reviews (rating + review count)
- At least 1 travel blog or food guide
- YouTube vlogs where available (search "[destination] [category] youtube")

**What to capture per place:**
- Name + address
- Rating + review count (Google and/or TripAdvisor)
- Why it's recommended (what reviewers consistently praise)
- Price range or entry info if relevant
- Any notable warnings from reviewers (scams, poor service, etc.)
- Hours / booking requirements

**Ranking logic:** Prioritize places that appear across multiple sources. A place with a 4.6 on Google + TripAdvisor Traveler's Choice + YouTube features beats a 4.9 on Google alone.

---

## Step 3 — Search for Place IDs

Use `places_search` to get Google Place IDs for all confirmed top picks.
- Search each place specifically: `"[Place Name] [City]"`
- Verify coordinates and details match
- Retrieve up to the top 3 per category

---

## Step 4 — Build the Map

Call `places_map_display_v0` with all locations as simple markers (not itinerary mode).

**Pin label format:**
```
[emoji] #[rank] [Place Name] ⭐[rating] ([review count] reviews)
```

**Emoji by category:**
- 🍽️ Buffets
- 🍜 Local food / restaurants
- 🎱 Pool halls / billiards
- 🍸 Bars & nightclubs
- 🛍️ Shopping malls / markets
- 🌙 Night markets
- ☕ Cafes
- 🐟 Seafood
- 🏖️ Beach clubs

**Pin notes field:** Include 2–3 punchy details from reviews:
- What it's best known for
- Standout dishes / features
- Practical tip (reserve ahead, cash only, etc.)

**Map narrative:** One sentence describing the research methodology.

---

## Step 5 — Summary Below the Map

After the map renders, provide a brief category-by-category breakdown in prose (no bullet lists). For each place include:
- Rating + source count
- What makes it the pick over alternatives
- Any important caveats from reviews (e.g. scams, wait times, cash only)

Keep it scannable — 2–4 sentences per place max.

---

## Research Quality Standards

- **Never use only Google Maps data.** Always cross-reference at least 2–3 external sources per category.
- **Flag reviewer warnings** — if multiple reviews mention scams, fake alcohol, or overcharging (common in some nightlife categories), note it clearly in the pin or summary.
- **Prefer recency** — weight 2024–2025 reviews and blog posts over older content.
- **Distinguish tourist traps** — places that rank highly on Google due to marketing but are panned by experienced travelers should be ranked lower or flagged.
- **Include a bonus pick** where a place is a strong honorable mention (e.g. a night market that fits multiple categories).

---

## Example Trigger Phrases

- "Top 3 places in Bangkok for food, bars, and shopping"
- "Make a Google map of the best spots in Hanoi"
- "Where should I go in Da Nang for buffets, local food, and nightlife?"
- "Best pool halls and bars in Ho Chi Minh City"
- "Give me a location guide for Bali"
- "Top attractions in Chiang Mai — restaurants, markets, nightlife"
