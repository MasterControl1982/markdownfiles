#!/usr/bin/env python3
"""
Validate and combine question CSVs for the 1000mapmath6th skill.

Reads multiple input CSVs, concatenates them, validates schema,
balances distribution, trims to exactly 1000 questions, assigns
sequential IDs, and writes the final CSV.

Usage:
    python3 validate.py input1.csv [input2.csv ...] --output final.csv
"""
import argparse
import csv
import sys
from collections import defaultdict, Counter

REQUIRED_HEADERS = ['id', 'strand', 'rit_band', 'difficulty_b', 'format', 'stem',
                    'image_url', 'choices', 'match_pairs', 'answer', 'tolerance', 'explanation']
VALID_STRANDS = {'OA', 'NO', 'GEO', 'MD'}
VALID_BANDS = {200, 210, 220, 230, 240, 250}
VALID_FORMATS = {'MC', 'NUMERIC', 'MULTI', 'MATCH'}
TARGET_TOTAL = 1000


def load_csv(path):
    rows = []
    with open(path, 'r', encoding='utf-8', newline='') as f:
        reader = csv.DictReader(f)
        missing = [h for h in REQUIRED_HEADERS if h not in reader.fieldnames]
        if missing:
            print(f"ERROR: {path} missing columns: {missing}", file=sys.stderr)
            sys.exit(1)
        for row in reader:
            rows.append(row)
    return rows


def validate_row(row, idx):
    errs = []
    if row['strand'] not in VALID_STRANDS:
        errs.append(f"row {idx}: bad strand '{row['strand']}'")
    try:
        band = int(row['rit_band'])
        if band not in VALID_BANDS:
            errs.append(f"row {idx}: bad rit_band {band}")
    except ValueError:
        errs.append(f"row {idx}: rit_band not int: '{row['rit_band']}'")
    if row['format'] not in VALID_FORMATS:
        errs.append(f"row {idx}: bad format '{row['format']}'")
    if not row['stem'].strip():
        errs.append(f"row {idx}: empty stem")
    if not row['answer'].strip():
        errs.append(f"row {idx}: empty answer")

    fmt = row['format']
    if fmt == 'MC' or fmt == 'MULTI':
        if not row['choices'].strip():
            errs.append(f"row {idx}: {fmt} requires choices")
        else:
            n_choices = len(row['choices'].split('|'))
            if n_choices < 2:
                errs.append(f"row {idx}: {fmt} needs ≥2 choices")
    if fmt == 'MATCH':
        if not row['match_pairs'].strip():
            errs.append(f"row {idx}: MATCH requires match_pairs")
    if fmt == 'NUMERIC':
        try:
            float(row['answer'])
        except ValueError:
            errs.append(f"row {idx}: NUMERIC answer not parseable: '{row['answer']}'")

    return errs


def balance_to_1000(rows):
    """
    Trim to exactly 1000 questions while keeping per-cell distribution
    as even as possible.
    Each cell = (strand, band, format).
    """
    by_cell = defaultdict(list)
    for r in rows:
        key = (r['strand'], int(r['rit_band']), r['format'])
        by_cell[key].append(r)

    # Compute target per cell
    n_cells = len(by_cell)
    if n_cells == 0:
        return []

    # Strategy: round-robin pick from cells until we hit 1000
    selected = []
    cell_iters = {k: iter(v) for k, v in by_cell.items()}
    cell_keys = list(by_cell.keys())

    while len(selected) < TARGET_TOTAL:
        added_this_round = 0
        for k in cell_keys:
            if len(selected) >= TARGET_TOTAL:
                break
            try:
                selected.append(next(cell_iters[k]))
                added_this_round += 1
            except StopIteration:
                continue
        if added_this_round == 0:
            # All cells exhausted before reaching 1000
            break

    return selected


def assign_ids(rows):
    for i, r in enumerate(rows, start=1):
        r['id'] = f"Q{i:04d}"
        # Force difficulty_b = rit_band
        r['difficulty_b'] = r['rit_band']
    return rows


def report(rows):
    by_strand = Counter(r['strand'] for r in rows)
    by_band = Counter(r['rit_band'] for r in rows)
    by_format = Counter(r['format'] for r in rows)
    by_cell = Counter((r['strand'], r['rit_band'], r['format']) for r in rows)

    print(f"\n=== Distribution Report ({len(rows)} questions) ===")
    print(f"By strand: {dict(by_strand)}")
    print(f"By RIT band: {dict(sorted(by_band.items()))}")
    print(f"By format: {dict(by_format)}")

    # Find empty or thin cells
    expected_cells = 4 * 6 * 4  # 96 cells
    actual_cells = len(by_cell)
    if actual_cells < expected_cells:
        missing = expected_cells - actual_cells
        print(f"⚠  {missing} of {expected_cells} cells (strand×band×format) are empty")
    thin = [k for k, v in by_cell.items() if v < 3]
    if thin:
        print(f"⚠  {len(thin)} cells have fewer than 3 questions")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('inputs', nargs='+', help='Input CSV files to merge')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()

    all_rows = []
    for path in args.inputs:
        rows = load_csv(path)
        all_rows.extend(rows)
        print(f"Loaded {len(rows)} from {path}")

    # Validate
    errs = []
    for i, r in enumerate(all_rows):
        errs.extend(validate_row(r, i))
    if errs:
        print(f"\n=== {len(errs)} validation errors ===", file=sys.stderr)
        for e in errs[:30]:
            print(f"  {e}", file=sys.stderr)
        if len(errs) > 30:
            print(f"  ... and {len(errs) - 30} more", file=sys.stderr)
        sys.exit(1)

    # Deduplicate by stem
    seen = set()
    unique = []
    for r in all_rows:
        s = r['stem'].strip()
        if s not in seen:
            seen.add(s)
            unique.append(r)
    if len(unique) < len(all_rows):
        print(f"Removed {len(all_rows) - len(unique)} duplicate stems")

    # Balance + trim
    final = balance_to_1000(unique)
    final = assign_ids(final)

    # Write
    with open(args.output, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=REQUIRED_HEADERS, quoting=csv.QUOTE_MINIMAL)
        w.writeheader()
        w.writerows(final)

    print(f"\n✓ Wrote {len(final)} questions to {args.output}")
    report(final)


if __name__ == '__main__':
    main()
