#!/usr/bin/env python3
"""
Procedural question generator for the 1000mapmath6th skill.

Produces MC and NUMERIC questions for OA, NO, GEO (computational), and MD strands
across all 6 RIT bands. All questions are guaranteed correct because answers are
computed at generation time.

Usage:
    python3 generate_procedural.py --output /tmp/procedural.csv [--seed 42]
"""
import argparse
import csv
import random
import math
from fractions import Fraction
from collections import defaultdict

BANDS = [200, 210, 220, 230, 240, 250]
STRANDS = ['OA', 'NO', 'GEO', 'MD']

# Target: 25 questions per (strand, band, format) cell for MC+NUMERIC
# = 4 strands × 6 bands × 2 formats × 25 = 1200 candidates
# Validator will trim to balance with authored content
PER_CELL_TARGET = 25


# ============================================================================
# Helpers
# ============================================================================

def csv_escape(s):
    """Quote field if it contains comma, quote, or newline."""
    s = str(s)
    if any(c in s for c in [',', '"', '\n']):
        return '"' + s.replace('"', '""') + '"'
    return s


def make_mc(stem, correct_value, distractors, explanation, strand, band, qid_counter):
    """Build an MC question row. Distractors must be 3 wrong values."""
    all_choices = [correct_value] + list(distractors)
    random.shuffle(all_choices)
    correct_idx = all_choices.index(correct_value)
    correct_letter = chr(65 + correct_idx)
    choices_str = '|'.join(f"{chr(65+i)}) {c}" for i, c in enumerate(all_choices))
    return {
        'id': '',  # validator assigns
        'strand': strand,
        'rit_band': band,
        'difficulty_b': band,
        'format': 'MC',
        'stem': stem,
        'image_url': '',
        'choices': choices_str,
        'match_pairs': '',
        'answer': correct_letter,
        'tolerance': '',
        'explanation': explanation,
    }


def make_numeric(stem, answer, explanation, strand, band, tolerance=0.01):
    return {
        'id': '',
        'strand': strand,
        'rit_band': band,
        'difficulty_b': band,
        'format': 'NUMERIC',
        'stem': stem,
        'image_url': '',
        'choices': '',
        'match_pairs': '',
        'answer': str(answer),
        'tolerance': str(tolerance),
        'explanation': explanation,
    }


def near_distractors(value, count=3, kind='int'):
    """Generate plausible wrong answers near the correct value."""
    distractors = set()
    attempts = 0
    while len(distractors) < count and attempts < 50:
        attempts += 1
        offset = random.choice([-3, -2, -1, 1, 2, 3, -10, 10])
        if kind == 'int':
            d = value + offset
            if d >= 0 and d != value:
                distractors.add(d)
        elif kind == 'float':
            d = round(value + offset * 0.1, 2)
            if d != value:
                distractors.add(d)
    while len(distractors) < count:
        distractors.add(value + len(distractors) + 100)
    return list(distractors)[:count]


# ============================================================================
# OA (Operations & Algebraic Thinking)
# ============================================================================

def gen_oa(band, count):
    """Generate OA questions for a given RIT band."""
    out = []
    for _ in range(count):
        if band == 200:
            # Order of operations, simple
            a, b, c = random.randint(2, 9), random.randint(2, 9), random.randint(2, 5)
            ans = a + b * c
            stem = f"What is the value of {a} + {b} × {c}?"
            expl = f"Multiply first: {b}×{c}={b*c}. Then add: {a}+{b*c}={ans}."
            out.append(('mc', stem, ans, expl))
        elif band == 210:
            # One-step equations
            x = random.randint(2, 12)
            b = random.randint(3, 15)
            sum_ = x + b
            stem = f"Solve for x: x + {b} = {sum_}"
            expl = f"Subtract {b} from both sides: x = {sum_} − {b} = {x}."
            out.append(('numeric', stem, x, expl))
        elif band == 220:
            # Two-step equations
            x = random.randint(2, 10)
            a = random.randint(2, 6)
            b = random.randint(1, 15)
            result = a * x + b
            stem = f"Solve for x: {a}x + {b} = {result}"
            expl = f"Subtract {b}: {a}x = {result-b}. Divide by {a}: x = {x}."
            out.append(('numeric', stem, x, expl))
        elif band == 230:
            # Distribute and solve
            x = random.randint(2, 10)
            a = random.randint(2, 5)
            b = random.randint(1, 8)
            c = random.randint(1, 6)
            # Equation: a(x + b) = a*x + a*b. Solve when result = a*(x+b)+c
            lhs_val = a * (x + b)
            stem = f"Evaluate {a}(x + {b}) when x = {x}."
            expl = f"{a}({x} + {b}) = {a}×{x+b} = {lhs_val}."
            out.append(('numeric', stem, lhs_val, expl))
        elif band == 240:
            # Inequalities
            x = random.randint(3, 12)
            a = random.randint(2, 4)
            b = random.randint(1, 10)
            threshold = a * x + b
            stem = f"What is the smallest integer x for which {a}x + {b} ≥ {threshold}?"
            expl = f"{a}x + {b} = {threshold} when x = {x}; so smallest x is {x}."
            out.append(('numeric', stem, x, expl))
        else:  # 250
            # Combined expressions
            x = random.randint(2, 8)
            y = random.randint(2, 8)
            ans = 3 * x * x - 2 * y + 5
            stem = f"Evaluate 3x² − 2y + 5 when x = {x} and y = {y}."
            expl = f"3({x})² − 2({y}) + 5 = {3*x*x} − {2*y} + 5 = {ans}."
            out.append(('numeric', stem, ans, expl))

    # Convert to question rows
    rows = []
    for kind, stem, ans, expl in out:
        if kind == 'mc':
            rows.append(make_mc(stem, ans, near_distractors(ans, 3, 'int'), expl, 'OA', band, None))
        else:
            rows.append(make_numeric(stem, ans, expl, 'OA', band, tolerance=0.01))
    return rows


# ============================================================================
# NO (Numbers & Operations)
# ============================================================================

def gen_no(band, count):
    out = []
    for _ in range(count):
        if band == 200:
            # Simple fraction-decimal recognition
            choices = [(Fraction(1,2), 0.5), (Fraction(1,4), 0.25), (Fraction(3,4), 0.75),
                       (Fraction(1,5), 0.2), (Fraction(2,5), 0.4), (Fraction(3,5), 0.6),
                       (Fraction(4,5), 0.8), (Fraction(1,10), 0.1)]
            f, d = random.choice(choices)
            stem = f"What is {f.numerator}/{f.denominator} as a decimal?"
            expl = f"{f.numerator} ÷ {f.denominator} = {d}."
            out.append(('numeric', stem, d, expl, 0.01))
        elif band == 210:
            # Add/subtract simple fractions, common denominator
            denom = random.choice([4, 5, 6, 8, 10])
            a = random.randint(1, denom-1)
            b = random.randint(1, denom-a-1) if denom-a > 1 else 1
            result = Fraction(a + b, denom)
            stem = f"What is {a}/{denom} + {b}/{denom}? (Give as a decimal)"
            expl = f"Add numerators: {a}+{b} = {a+b}. Result: {a+b}/{denom} = {float(result):.3f}."
            out.append(('numeric', stem, round(float(result), 3), expl, 0.01))
        elif band == 220:
            # Fraction multiplication
            n1, d1 = random.randint(1, 4), random.randint(2, 6)
            n2, d2 = random.randint(1, 4), random.randint(2, 6)
            f = Fraction(n1, d1) * Fraction(n2, d2)
            stem = f"What is {n1}/{d1} × {n2}/{d2}? (Give as a decimal, round to 3 places)"
            expl = f"Multiply: ({n1}×{n2})/({d1}×{d2}) = {n1*n2}/{d1*d2} = {float(f):.3f}."
            out.append(('numeric', stem, round(float(f), 3), expl, 0.01))
        elif band == 230:
            # Percent of a number
            pct = random.choice([10, 20, 25, 30, 40, 50, 60, 75])
            n = random.randint(2, 20) * 5  # multiple of 5
            ans = n * pct / 100
            stem = f"What is {pct}% of {n}?"
            expl = f"{pct}% = {pct/100}; {pct/100} × {n} = {ans}."
            out.append(('numeric', stem, ans, expl, 0.01))
        elif band == 240:
            # Ratios and proportions
            a = random.randint(2, 8)
            b = random.randint(2, 6)
            k = random.randint(2, 5)
            stem = f"If the ratio of red to blue marbles is {a}:{b} and there are {a*k} red marbles, how many blue marbles are there?"
            ans = b * k
            expl = f"Scale factor is {a*k}/{a} = {k}. Blue marbles = {b}×{k} = {ans}."
            out.append(('numeric', stem, ans, expl, 0))
        else:  # 250
            # Integer operations and complex expressions
            a = random.randint(-10, -1)
            b = random.randint(2, 12)
            c = random.randint(-8, -1)
            ans = a * b - c
            stem = f"Evaluate ({a}) × {b} − ({c})."
            expl = f"{a}×{b} = {a*b}. {a*b} − ({c}) = {a*b} + {-c} = {ans}."
            out.append(('numeric', stem, ans, expl, 0))

    rows = []
    for entry in out:
        kind, stem, ans, expl, tol = entry
        rows.append(make_numeric(stem, ans, expl, 'NO', band, tolerance=tol))
    return rows


# ============================================================================
# GEO (Geometry — computational only)
# ============================================================================

def gen_geo(band, count):
    out = []
    for _ in range(count):
        if band == 200:
            # Polygon vertex count
            shapes = [('triangle', 3), ('square', 4), ('pentagon', 5),
                      ('hexagon', 6), ('octagon', 8)]
            name, n = random.choice(shapes)
            stem = f"How many sides does a {name} have?"
            expl = f"A {name} has {n} sides by definition."
            out.append(('mc', stem, n, expl))
        elif band == 210:
            # Rectangle area
            l, w = random.randint(3, 12), random.randint(2, 10)
            ans = l * w
            stem = f"What is the area of a rectangle with length {l} and width {w}?"
            expl = f"Area = length × width = {l}×{w} = {ans}."
            out.append(('numeric', stem, ans, expl))
        elif band == 220:
            # Rectangle perimeter
            l, w = random.randint(3, 15), random.randint(2, 12)
            ans = 2 * (l + w)
            stem = f"What is the perimeter of a rectangle with length {l} and width {w}?"
            expl = f"Perimeter = 2(l+w) = 2({l}+{w}) = {ans}."
            out.append(('numeric', stem, ans, expl))
        elif band == 230:
            # Triangle area
            b, h = random.choice([4, 6, 8, 10, 12]), random.choice([3, 5, 7, 9])
            ans = b * h / 2
            stem = f"What is the area of a triangle with base {b} and height {h}?"
            expl = f"Area = ½ × base × height = ½ × {b} × {h} = {ans}."
            out.append(('numeric', stem, ans, expl))
        elif band == 240:
            # Volume of rectangular prism
            l, w, h = random.randint(2, 8), random.randint(2, 7), random.randint(2, 6)
            ans = l * w * h
            stem = f"What is the volume of a rectangular prism with length {l}, width {w}, and height {h}?"
            expl = f"Volume = l × w × h = {l}×{w}×{h} = {ans}."
            out.append(('numeric', stem, ans, expl))
        else:  # 250
            # Circle circumference (use π ≈ 3.14)
            r = random.randint(2, 10)
            ans = round(2 * 3.14 * r, 2)
            stem = f"What is the circumference of a circle with radius {r}? Use π ≈ 3.14."
            expl = f"Circumference = 2πr = 2 × 3.14 × {r} = {ans}."
            out.append(('numeric', stem, ans, expl))

    rows = []
    for entry in out:
        kind, stem, ans, expl = entry
        if kind == 'mc':
            rows.append(make_mc(stem, ans, near_distractors(ans, 3, 'int'), expl, 'GEO', band, None))
        else:
            rows.append(make_numeric(stem, ans, expl, 'GEO', band, tolerance=0.01))
    return rows


# ============================================================================
# MD (Measurement & Data)
# ============================================================================

def gen_md(band, count):
    out = []
    for _ in range(count):
        if band == 200:
            # Reading a small data set: mode
            data = sorted([random.randint(1, 9) for _ in range(5)])
            # Force a mode by duplicating one
            mode_val = random.choice(data)
            data.append(mode_val)
            data = sorted(data)
            stem = f"What is the mode of: {', '.join(map(str, data))}?"
            expl = f"Mode = most frequent value = {mode_val}."
            out.append(('mc', stem, mode_val, expl))
        elif band == 210:
            # Median of odd-length list
            data = sorted(random.sample(range(1, 30), 5))
            ans = data[2]
            stem = f"What is the median of: {', '.join(map(str, data))}?"
            expl = f"Sorted middle value of 5 numbers is the 3rd = {ans}."
            out.append(('numeric', stem, ans, expl))
        elif band == 220:
            # Mean
            data = [random.randint(2, 20) for _ in range(5)]
            # ensure clean mean
            data[0] = (5 * random.randint(5, 15)) - sum(data[1:])
            data[0] = max(1, data[0])
            ans = sum(data) / 5
            stem = f"What is the mean of: {', '.join(map(str, data))}?"
            expl = f"Sum = {sum(data)}, count = 5, mean = {ans}."
            out.append(('numeric', stem, ans, expl))
        elif band == 230:
            # Probability of a single event
            total_red = random.randint(2, 6)
            total_blue = random.randint(2, 6)
            total_green = random.randint(1, 4)
            total = total_red + total_blue + total_green
            color = random.choice(['red', 'blue', 'green'])
            count_ = {'red': total_red, 'blue': total_blue, 'green': total_green}[color]
            ans = round(count_ / total, 3)
            stem = f"A bag has {total_red} red, {total_blue} blue, and {total_green} green marbles. What is the probability of drawing a {color} marble? (Decimal, round to 3 places)"
            expl = f"P({color}) = {count_}/{total} = {ans}."
            out.append(('numeric', stem, ans, expl))
        elif band == 240:
            # Range
            data = [random.randint(5, 80) for _ in range(6)]
            ans = max(data) - min(data)
            stem = f"What is the range of: {', '.join(map(str, data))}?"
            expl = f"Range = max − min = {max(data)} − {min(data)} = {ans}."
            out.append(('numeric', stem, ans, expl))
        else:  # 250
            # Unit conversion
            ft = random.randint(2, 12)
            inches = ft * 12
            stem = f"How many inches are in {ft} feet? (1 foot = 12 inches)"
            expl = f"{ft} × 12 = {inches} inches."
            out.append(('numeric', stem, inches, expl))

    rows = []
    for entry in out:
        kind, stem, ans, expl = entry
        if kind == 'mc':
            rows.append(make_mc(stem, ans, near_distractors(ans, 3, 'int'), expl, 'MD', band, None))
        else:
            rows.append(make_numeric(stem, ans, expl, 'MD', band, tolerance=0.01))
    return rows


# ============================================================================
# Main
# ============================================================================

GENERATORS = {'OA': gen_oa, 'NO': gen_no, 'GEO': gen_geo, 'MD': gen_md}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, help='Output CSV path')
    parser.add_argument('--per-cell', type=int, default=PER_CELL_TARGET,
                        help='Questions per (strand × band) cell')
    parser.add_argument('--seed', type=int, default=None, help='Random seed for reproducibility')
    args = parser.parse_args()

    if args.seed is not None:
        random.seed(args.seed)

    all_rows = []
    for strand in STRANDS:
        gen = GENERATORS[strand]
        for band in BANDS:
            rows = gen(band, args.per_cell)
            # Deduplicate by stem
            seen = set()
            unique = []
            for r in rows:
                if r['stem'] not in seen:
                    seen.add(r['stem'])
                    unique.append(r)
            all_rows.extend(unique)

    # Write CSV
    headers = ['id', 'strand', 'rit_band', 'difficulty_b', 'format', 'stem',
               'image_url', 'choices', 'match_pairs', 'answer', 'tolerance', 'explanation']
    with open(args.output, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_MINIMAL)
        w.writeheader()
        w.writerows(all_rows)

    # Summary
    by_cell = defaultdict(int)
    by_format = defaultdict(int)
    for r in all_rows:
        by_cell[(r['strand'], r['rit_band'])] += 1
        by_format[r['format']] += 1

    print(f"✓ Wrote {len(all_rows)} questions to {args.output}")
    print(f"  By format: {dict(by_format)}")
    print(f"  By strand/band cell:")
    for strand in STRANDS:
        cells = [by_cell[(strand, b)] for b in BANDS]
        print(f"    {strand}: {cells} (bands {BANDS})")


if __name__ == '__main__':
    main()
