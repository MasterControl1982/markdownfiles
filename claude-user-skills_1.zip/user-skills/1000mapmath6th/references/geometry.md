# Geometry Authoring Templates

Read this when authoring GEO questions that go beyond pure computation (which the procedural script handles). Focuses on identification, properties, transformations, and coordinate geometry.

## Band 200 — Shape identification and basic properties

> **Stem:** Which shape has exactly 4 equal sides and 4 right angles?
> **Format:** MC
> **Choices:** A) Rectangle | B) Square | C) Rhombus | D) Trapezoid
> **Answer:** B
> **Explanation:** A square has 4 equal sides AND 4 right angles. A rectangle has 4 right angles but unequal sides; a rhombus has 4 equal sides but not necessarily right angles.

## Band 210 — Angle classification

> **Stem:** An angle that measures 90° is called what kind of angle?
> **Format:** MC
> **Choices:** A) Acute | B) Obtuse | C) Right | D) Straight
> **Answer:** C
> **Explanation:** A 90° angle is a right angle. Acute < 90°, obtuse > 90°, straight = 180°.

## Band 220 — Properties of polygons

> **Stem:** How many lines of symmetry does a regular hexagon have?
> **Format:** NUMERIC
> **Answer:** 6
> **Explanation:** A regular hexagon has 6 lines of symmetry: 3 through opposite vertices, 3 through opposite edge midpoints.

## Band 230 — Coordinate geometry

> **Stem:** What is the distance from the point (3, 0) to the point (3, 7) on a coordinate plane?
> **Format:** NUMERIC
> **Answer:** 7
> **Explanation:** Both points have x = 3, so they're on a vertical line. Distance = |7 − 0| = 7.

> **Stem:** A rectangle has vertices at (0, 0), (5, 0), (5, 3), and (0, 3). What is its area?
> **Format:** NUMERIC
> **Answer:** 15
> **Explanation:** Width = 5, height = 3. Area = 5 × 3 = 15.

## Band 240 — Transformations

> **Stem:** A point is at (4, 2). After being reflected across the y-axis, what are its new coordinates?
> **Format:** MC
> **Choices:** A) (-4, 2) | B) (4, -2) | C) (-4, -2) | D) (2, 4)
> **Answer:** A
> **Explanation:** Reflection across the y-axis flips the sign of x. (4, 2) becomes (-4, 2).

> **Stem:** A triangle is translated 3 units right and 2 units down. If one vertex is originally at (1, 5), where is it after translation?
> **Format:** MC
> **Choices:** A) (4, 7) | B) (4, 3) | C) (-2, 3) | D) (4, 5)
> **Answer:** B
> **Explanation:** Right 3 → x + 3. Down 2 → y − 2. (1+3, 5−2) = (4, 3).

## Band 250 — Composite figures and circles

> **Stem:** A square has a side length of 8. What is the length of its diagonal? Use √2 ≈ 1.414. (Round to 2 decimal places.)
> **Format:** NUMERIC
> **Answer:** 11.31
> **Explanation:** Diagonal of a square = side × √2 = 8 × 1.414 = 11.312 ≈ 11.31.

> **Stem:** A circle has a radius of 5. What is its area? Use π ≈ 3.14. (Round to 2 decimal places.)
> **Format:** NUMERIC
> **Answer:** 78.5
> **Explanation:** Area = πr² = 3.14 × 25 = 78.5.

## Authoring rules

1. **Avoid image dependence** unless `image_url` is set. Don't write "as shown" without a verified image.
2. **Coordinate questions**: state the points explicitly in the stem. Don't say "the triangle in the figure".
3. **For circles**: tell the student which π approximation to use (3.14 or 22/7) and the rounding precision. Set tolerance to `0.05`.
4. **For square roots and irrationals**: provide the approximation in the stem.
5. **Properties questions** (vertices, sides, symmetry) are pure recall — keep them at lower bands (200–220).
6. **Transformations** (reflection, translation, rotation) are bands 230–250.

## Image URLs

If you do want to include an image_url, the safest options are:
- Wikipedia's geometry SVG files (e.g., `https://upload.wikimedia.org/wikipedia/commons/...`)
- Public-domain math resources at openstax.org or illustrativemathematics.org

Do NOT invent URLs. If you can't verify a URL exists, leave the field blank and describe the figure in text.
