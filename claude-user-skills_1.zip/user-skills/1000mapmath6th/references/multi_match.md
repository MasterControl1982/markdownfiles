# MULTI and MATCH Authoring Guide

These two formats need careful authoring. Get the format spec exactly right or the app won't grade them.

## MULTI (Multi-select / Select All That Apply)

### Format spec

- 4 to 6 choices, listed in `choices` column as `A) text|B) text|...`
- 2 to 4 of those choices are correct
- `answer` column is comma-separated letters: e.g. `A,C` or `B,C,D`
- The student must pick the EXACT correct subset to be marked correct (no partial credit)

### Example: OA, band 220

> **Stem:** Which of the following equations have x = 5 as a solution? Select all that apply.
> **Choices:** A) 2x = 10 | B) x + 3 = 8 | C) 3x − 2 = 14 | D) x/2 = 3
> **Answer:** A,B
> **Explanation:** A: 2(5)=10 ✓. B: 5+3=8 ✓. C: 3(5)−2=13, not 14 ✗. D: 5/2=2.5, not 3 ✗.

### Example: NO, band 230

> **Stem:** Which of the following are equivalent to 0.6? Select all that apply.
> **Choices:** A) 3/5 | B) 6/10 | C) 60% | D) 0.06 | E) 6/100
> **Answer:** A,B,C
> **Explanation:** 0.6 = 3/5 = 6/10 = 60%. 0.06 ≠ 0.6. 6/100 = 0.06 ≠ 0.6.

### Example: GEO, band 220

> **Stem:** Which of the following are properties of a square? Select all that apply.
> **Choices:** A) 4 equal sides | B) 4 right angles | C) Opposite sides parallel | D) Only 2 lines of symmetry | E) All angles sum to 360°
> **Answer:** A,B,C,E
> **Explanation:** A square has 4 equal sides, 4 right angles, parallel opposite sides, and angle sum 360°. It has 4 lines of symmetry, not 2.

### Example: MD, band 240

> **Stem:** Which statements about the data set {3, 5, 5, 8, 11, 12} are true? Select all that apply.
> **Choices:** A) Mode is 5 | B) Median is 6.5 | C) Range is 9 | D) Mean is 7.5 | E) All values are odd
> **Answer:** A,B,C
> **Explanation:** Mode=5 ✓. Median = (5+8)/2 = 6.5 ✓. Range = 12−3 = 9 ✓. Mean = 44/6 ≈ 7.33, not 7.5 ✗. Not all odd ✗.

### Authoring rules for MULTI

1. **Always have at least 2 correct answers** — single-correct MULTI is just MC.
2. **Avoid "All of the above" or "None of the above"** as choices. They short-circuit the format.
3. **Each wrong choice should be plausible** — a common misconception, not nonsense.
4. **State "Select all that apply"** clearly in the stem.
5. **Cap at 6 choices** for screen readability.

## MATCH (Matching pairs)

### Format spec

- 3 to 6 left-side keys, each paired with a unique right-side value
- `match_pairs` column: `Left1=Right1|Left2=Right2|...`
- `answer` column: same string as `match_pairs`
- `choices` column: leave empty
- Right-side values are shuffled in the UI; student matches each left to its right

### Example: GEO, band 200

> **Stem:** Match each polygon to its number of sides.
> **match_pairs:** Triangle=3|Square=4|Pentagon=5|Hexagon=6
> **Answer:** Triangle=3|Square=4|Pentagon=5|Hexagon=6
> **Explanation:** Triangle has 3 sides, square 4, pentagon 5, hexagon 6.

### Example: NO, band 220

> **Stem:** Match each fraction to its decimal equivalent.
> **match_pairs:** 1/2=0.5|1/4=0.25|3/4=0.75|1/5=0.2
> **Answer:** 1/2=0.5|1/4=0.25|3/4=0.75|1/5=0.2
> **Explanation:** Each fraction divided by its denominator gives the decimal.

### Example: OA, band 240

> **Stem:** Match each equation to the value of x that solves it.
> **match_pairs:** 2x+3=11=4|x/3=5=15|x-7=10=17|3x=24=8
> **Answer:** 2x+3=11=4|x/3=5=15|x-7=10=17|3x=24=8

⚠ The above example has a problem: equations contain `=` signs, which conflicts with the `key=value` delimiter. **Use this workaround for equations:**

> **Stem:** Match each equation to its solution for x.
> **match_pairs:** 2x+3 equals 11=4|x/3 equals 5=15|x minus 7 equals 10=17|3x equals 24=8
> **Answer:** 2x+3 equals 11=4|x/3 equals 5=15|x minus 7 equals 10=17|3x equals 24=8

Or rephrase the keys to avoid `=`:

> **Stem:** Match each expression to its value when x = 4.
> **match_pairs:** 2x+1=9|3x−2=10|x²=16|x/2=2
> **Answer:** 2x+1=9|3x−2=10|x²=16|x/2=2

### Example: MD, band 230

> **Stem:** Match each statistic name to its value for the data set {2, 4, 6, 8, 10}.
> **match_pairs:** Mean=6|Median=6|Range=8|Mode=none
> **Answer:** Mean=6|Median=6|Range=8|Mode=none

### Authoring rules for MATCH

1. **One-to-one only** — each right-side value should appear exactly once. Don't have two left-side keys both match to the same right value.
2. **Use 3 to 6 pairs.** Fewer = trivial, more = exhausting.
3. **No `=` or `|` characters in keys or values.** These break the parser. Spell out "equals" or rephrase.
4. **Both left and right sides should be short** — under 20 characters each.
5. **The `answer` column must equal `match_pairs` exactly** — same string, same order.
6. **The `choices` column must be empty** for MATCH questions.

## Distribution targets

- **MULTI**: 5 per (strand × band) cell → 24 cells × 5 = 120 questions
- **MATCH**: 3 per (strand × band) cell → 24 cells × 3 = 72 questions

The procedural script does NOT generate these formats. All MULTI and MATCH content must be Claude-authored using the templates above.
