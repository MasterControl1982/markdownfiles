# Word Problem Authoring Templates

Read this when authoring word problems for OA and NO strands. Each template includes a band, a frame, and a worked example.

## OA Word Problems

### Band 200 — Single-step real-world arithmetic

**Frame:** Person has X items, gives away/buys Y, how many now?

> **Stem:** Maria has 24 stickers. She gives 7 to her brother. How many does she have left?
> **Answer:** 17
> **Format:** NUMERIC, tolerance 0
> **Explanation:** 24 − 7 = 17.

### Band 210 — Two-step word problems

**Frame:** Buying multiple items at a price, plus a fee/tax/shipping.

> **Stem:** A book costs $8. Carlos buys 3 books and pays a $2 shipping fee. What is his total cost in dollars?
> **Answer:** 26
> **Explanation:** 3 books × $8 = $24. Add shipping: $24 + $2 = $26.

### Band 220 — Equation setup

**Frame:** Unknown is described in words; student writes and solves equation.

> **Stem:** A pencil costs 3 times as much as an eraser. Together they cost $1.20. How many cents does the eraser cost?
> **Answer:** 30
> **Explanation:** Let eraser = x. Pencil = 3x. x + 3x = 120, so 4x = 120, x = 30 cents.

### Band 230 — Multi-step with extra info

**Frame:** Embed a distractor number; student must filter to the operation that matters.

> **Stem:** A school has 480 students in 6 grades. The 6th grade has 95 students. The 7th grade has 12 more students than the 6th grade. How many students are in 7th grade?
> **Answer:** 107
> **Explanation:** 95 + 12 = 107. (The 480 total is a distractor.)

### Band 240 — Inequalities and constraints

**Frame:** "At least / at most" budgeting problems.

> **Stem:** Tickets cost $7 each. Ana has $50. What is the largest whole number of tickets she can buy?
> **Answer:** 7
> **Explanation:** 50 ÷ 7 = 7.14..., so she can buy 7 tickets (7×7=$49).

### Band 250 — Rate / work / mixed

**Frame:** Rates, percents, multi-step.

> **Stem:** A printer prints 12 pages per minute. How many minutes does it take to print a 180-page document?
> **Answer:** 15
> **Explanation:** 180 ÷ 12 = 15 minutes.

## NO Word Problems

### Band 200 — Whole number money

> **Stem:** Apples cost $3 each. How much do 5 apples cost?
> **Answer:** 15
> **Explanation:** 5 × $3 = $15.

### Band 210 — Fractions in context

> **Stem:** Sam ate ¼ of a pizza on Monday and ½ on Tuesday. What fraction of the pizza did he eat in total? (Decimal form, round to 2 places)
> **Answer:** 0.75
> **Explanation:** ¼ + ½ = ¼ + 2/4 = ¾ = 0.75.

### Band 220 — Decimals in context

> **Stem:** A pen costs $1.25 and a notebook costs $2.40. How much do 2 pens and 1 notebook cost in dollars?
> **Answer:** 4.90
> **Explanation:** 2 × $1.25 = $2.50. $2.50 + $2.40 = $4.90.

### Band 230 — Percent of amount

> **Stem:** A jacket originally costs $80 and is on sale for 30% off. What is the sale price in dollars?
> **Answer:** 56
> **Explanation:** Discount = 0.30 × $80 = $24. Sale = $80 − $24 = $56.

### Band 240 — Ratio scaling

> **Stem:** A recipe calls for 3 cups of flour and 2 cups of sugar. If a baker uses 9 cups of flour, how many cups of sugar should he use?
> **Answer:** 6
> **Explanation:** Scale factor = 9/3 = 3. Sugar = 2 × 3 = 6 cups.

### Band 250 — Compound percent / multi-step

> **Stem:** A shirt is marked down 25%, then an additional 10% is taken off the sale price. If the original price was $40, what is the final price in dollars?
> **Answer:** 27
> **Explanation:** After 25% off: 0.75 × $40 = $30. After 10% off: 0.90 × $30 = $27.

## Authoring rules

1. **Use specific names and contexts**, not "Person A bought X widgets". Real-feeling stories engage 6th graders.
2. **Money problems**: ask for the answer in dollars OR cents (specify), not both.
3. **No trick wording** — the question should test math, not reading comprehension.
4. **Vary the operations** — don't make every word problem at a band the same operation.
5. **Distractors for MC** should reflect realistic mistakes:
   - Wrong operation (added instead of subtracted)
   - Off by an order of magnitude (×10 or ÷10 error)
   - Forgot a step (single-step answer for a two-step problem)
6. **Tolerance** for money: `0.01`. For whole numbers: `0`.
