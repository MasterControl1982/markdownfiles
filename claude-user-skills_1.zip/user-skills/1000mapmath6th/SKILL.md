---
name: 1000mapmath6th
description: Generates a 1000-question 6th-grade math practice bank (CSV) for the MAP Math Practice app. Triggers on /1000mapmath6th and on any request to generate, build, refresh, or refill a question bank for the MAP practice site, NWEA-style 6th grade math practice questions, or weekly question refresh. Use this skill whenever the user mentions generating questions for the practice site, weekly bank, MAP math, RIT-aligned questions, or asks to refill/refresh/regenerate the math question bank — even if they don't say "skill" or "1000" explicitly. Produces a CSV in the exact schema the practice app consumes (id, strand, rit_band, difficulty_b, format, stem, image_url, choices, match_pairs, answer, tolerance, explanation), distributed across 4 strands × 6 RIT bands × 4 formats. Mix of procedurally-generated arithmetic (script-verified) and Claude-authored word problems and geometry questions.
---

# 1000mapmath6th

Generate a complete 1000-question MAP-style math practice bank for 6th grade. Output is a single CSV file in the exact schema consumed by the MAP Math Practice app: `id, strand, rit_band, difficulty_b, format, stem, image_url, choices, match_pairs, answer, tolerance, explanation`.

## When this skill triggers

- User types `/1000mapmath6th`
- User says "generate the question bank", "refill the bank", "weekly questions", "refresh the bank", or any variation
- User asks for MAP-style 6th grade math questions in bulk
- User mentions the practice site needs new questions

## Distribution target

The 1000 questions must be distributed evenly across **strand × RIT band × format**:

| Dimension | Values |
|---|---|
| Strand (4) | OA (Operations & Algebraic), NO (Numbers & Operations), GEO (Geometry), MD (Measurement & Data) |
| RIT band (6) | 200, 210, 220, 230, 240, 250 |
| Format (4) | MC, NUMERIC, MULTI, MATCH |

Grid math: 4 strands × 6 bands × ~42 questions per cell = ~1008. Round to exactly 1000 by trimming 2 from the largest cells.

**Per cell of 42 questions, target this format split:**
- MC: 22 (more multiple choice — easiest to author and verify)
- NUMERIC: 12
- MULTI: 5
- MATCH: 3

## High-level workflow

Follow these steps in order. Each step has its own section below.

1. **Run the procedural generator** for arithmetic-heavy questions (OA + NO at all bands, plus simple MC/NUMERIC for GEO/MD where applicable). This gives ~600 questions in seconds, all guaranteed correct.
2. **Author the word-problem and geometry questions** yourself (Claude). This is the remaining ~400, where templates can't capture grade-appropriate variety. Use the templates in `references/word_problems.md` and `references/geometry.md`.
3. **Author all MULTI and MATCH questions** yourself — these formats need careful design that the procedural generator doesn't handle.
4. **Combine and validate** with `scripts/validate.py`.
5. **Output the final CSV** to `/mnt/user-data/outputs/questions_bank.csv` and present it.

## Step 1: Procedural generation

Run the script to produce arithmetic and computational questions:

```bash
cd /mnt/skills/user/1000mapmath6th
python3 scripts/generate_procedural.py --output /tmp/procedural.csv
```

The script handles:
- **OA**: order of operations (200), one-step equations (210), two-step equations (220-230), expressions/inequalities (240-250)
- **NO**: fraction/decimal/percent conversions, fraction arithmetic, ratios, GCF/LCM, integer operations
- **GEO**: area/perimeter/volume calculations on rectangles, triangles, circles, prisms (when only computation is involved)
- **MD**: mean/median/mode/range, simple probability, unit conversions

It produces **MC and NUMERIC questions only**. MULTI and MATCH come from Claude-authored content in step 3.

Expected output: ~600 questions covering all 6 RIT bands × 4 strands × {MC, NUMERIC}.

If the script fails or produces fewer than expected, read `scripts/generate_procedural.py` to debug — don't proceed until step 1 yields a valid CSV.

## Step 2: Author word problems and geometry

Read `references/word_problems.md` and `references/geometry.md` for templates and examples. Author questions for these areas where procedural generation falls short:

- **OA word problems** at every RIT band (real-world expressions, age problems, work problems)
- **NO word problems** (recipes, money, percent-of-amount stories)
- **GEO non-computational** (identifying shapes by properties, coordinate geometry, transformations)
- **MD interpretation** (reading graphs, drawing inferences from data, complex probability)

Target counts per cell (per strand × band):
- OA word problems: ~5 per band → 30 total
- NO word problems: ~5 per band → 30 total
- GEO authored: ~10 per band → 60 total
- MD authored: ~10 per band → 60 total
- **Subtotal: ~180 questions**

These are all MC or NUMERIC. Append them to a separate CSV: `/tmp/authored_mc_numeric.csv`.

Critical rules when authoring:
- Stems must be self-contained — no "as shown above" without an image_url
- Numeric answers must be unambiguous (one correct value, exact or with explicit tolerance)
- Multiple choice distractors should reflect common student errors, not random wrong numbers
- Use plain text only — no LaTeX (the app doesn't render it)
- Use unicode for math: × ÷ ≤ ≥ ½ ⅓ ¼ ⅔ ¾ etc.
- Do NOT use markdown formatting in stems (no `**bold**`, no `$math$`)
- Reference correct geometry images at public URLs ONLY if you are certain they exist; otherwise leave `image_url` blank and describe the figure in words within the stem

## Step 3: Author MULTI and MATCH questions

Read `references/multi_match.md` for the format spec and authoring rules.

Target counts:
- MULTI: 5 per cell × 24 cells = 120 questions
- MATCH: 3 per cell × 24 cells = 72 questions
- **Subtotal: ~192 questions** (round up so the grand total comes to 1000)

Append to `/tmp/authored_multi_match.csv`.

Critical rules:
- **MULTI**: must have 4–6 choices, with 2–4 of them correct. Single-correct-answer MULTI defeats the purpose.
- **MATCH**: must have 3–6 pairs. Don't reuse a right-side value across two left-side keys (one-to-one only).
- For MATCH, the `answer` column should equal the `match_pairs` column.

## Step 4: Validate and combine

Run the validator:

```bash
python3 /mnt/skills/user/1000mapmath6th/scripts/validate.py \
    /tmp/procedural.csv \
    /tmp/authored_mc_numeric.csv \
    /tmp/authored_multi_match.csv \
    --output /mnt/user-data/outputs/questions_bank.csv
```

The validator:
- Concatenates all input CSVs
- Reassigns sequential IDs (`Q0001`–`Q1000`)
- Verifies the schema (all required columns present, no missing fields per format)
- Checks for duplicate stems
- Confirms per-cell distribution (logs warnings if any strand × band × format cell is empty or overpopulated)
- Trims to exactly 1000 questions, keeping the distribution balanced
- Sets `difficulty_b` to equal `rit_band` (the app's IRT engine uses this as the starting difficulty)
- Writes the final CSV

If the validator reports schema errors, FIX them before proceeding. Do not deliver a broken CSV.

## Step 5: Deliver

Use `present_files` to give the user the final CSV at `/mnt/user-data/outputs/questions_bank.csv`.

Include a short summary:
- Total questions produced
- Distribution: how many per strand, per RIT band, per format
- Any warnings the validator surfaced

## Schema reference (must match exactly)

| Column | Type | Required for | Notes |
|---|---|---|---|
| `id` | string | all | Sequential `Q0001`–`Q1000`, assigned by validator |
| `strand` | enum | all | `OA`, `NO`, `GEO`, `MD` |
| `rit_band` | int | all | `200`, `210`, `220`, `230`, `240`, `250` |
| `difficulty_b` | float | all | Set equal to `rit_band` |
| `format` | enum | all | `MC`, `NUMERIC`, `MULTI`, `MATCH` |
| `stem` | string | all | Plain text, unicode math OK |
| `image_url` | string | optional | Leave blank unless you have a verified public image URL |
| `choices` | string | MC, MULTI | `A) text\|B) text\|C) text\|D) text` |
| `match_pairs` | string | MATCH | `Left1=Right1\|Left2=Right2\|...` |
| `answer` | string | all | MC: `B`. NUMERIC: `15` or `15.5`. MULTI: `A,C`. MATCH: same as `match_pairs` |
| `tolerance` | float | NUMERIC | e.g. `0.01` |
| `explanation` | string | all | Why the answer is correct |

## RIT band difficulty calibration (use these mental anchors)

| Band | What a 6th grader at this level can do |
|---|---|
| 200 | One-step arithmetic with whole numbers; basic shape names; simple data reading |
| 210 | Two-step arithmetic; one-step equations; fraction/decimal recognition |
| 220 | Two-step equations; fraction operations; area/perimeter; mean/median |
| 230 | Multi-step word problems; ratio/proportion; volume; basic probability |
| 240 | Inequalities; percent applications; coordinate geometry; data interpretation |
| 250 | Advanced expressions; complex word problems; circle area; combined operations |

When in doubt about which band a question belongs in, give it to a 6th-grade teacher's gut: would the average 6th grader get this right ~50% of the time? That's the on-grade band (220).

## Common mistakes to avoid

- Generating questions in markdown rather than the CSV format — always output CSV-compatible strings
- Forgetting to escape commas in CSV cells — wrap any cell containing a comma in `"double quotes"`
- Repeating the same question with trivial number swaps — the procedural script handles this but Claude-authored content needs variety
- Using LaTeX (`\frac{1}{2}`) — the app shows raw text, so write `½` or `1/2`
- Off-grade questions — calculus is not 6th grade math, neither is multi-digit long division as a primary task
- Missing the `tolerance` field on NUMERIC questions — set it to `0.01` for decimals, `0` or omit for whole-number answers
